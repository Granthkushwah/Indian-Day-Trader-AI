# Architecture

```text
Codex Agent Skills (11 SKILL.md files)
                 |
                 v
       indian_trader.cli (one command entry point)
                 |
   +-------------+------------------------------+
   |             |              |               |
   v             v              v               v
Market data   Strategy       Risk/INR       Paper broker
 CSV/Angel SmartAPI/Groww scan/entry/exit budget/check  JSON ledger only
   |             |              |               |
   +------ candles / instrument metadata ------+
                 |
          Backtest + reports
```

`indian_trader/` owns shared logic; skills are short task-specific operator guides that call it. The market-data boundary normalizes bars to timestamp, exchange, symbol, OHLCV and optional token. `CsvMarketData` is deterministic and offline. `SmartApiClient` calls only Angel One market-data endpoints; `GrowwDataClient` calls only Groww historical-candle and live-quote GET endpoints. Neither client has order endpoints or order-shaped methods. Local PowerShell helpers retain session tokens in the current shell environment and do not write credentials to disk. REST requests are paced locally; valid authorized tokens and current broker entitlements are still required.

The paper broker stores local simulated orders/fills/positions in `trader/paper_ledger.json`. It is isolated from Angel One and Groww data adapters and has no network dependency. Risk configuration and costs are plain editable JSON. The calendar is exchange-keyed and has fixed IST times; official holidays and special sessions are explicit data, never inferred from an unrelated exchange.

The system fails closed for missing CSV columns, missing credentials, missing stop/risk values, and disabled/unknown session configuration. CLI output identifies the data source and timestamp where available. No market prices are bundled as examples.
