# Original source inspection record

Both supplied originals were inspected before project edits. The PDF was confirmed as 13 pages, text-extracted page by page, rendered, and visually reviewed as a complete contact sheet. The ZIP contains 11 nested skill archives; archive members were inventoried with sizes and SHA-256 values, the nested files were extracted to temporary review space, all 11 `SKILL.md` files and all 11 Python programs were reviewed, and every Python file passed syntax parsing. The original inputs in Downloads were left untouched.

## Guide findings

The setup guide describes an 11-skill Claude/Claude Code workflow for US stocks, a Python 3.8+ toolset, US exchanges and New York time, USD budgets and limits, Yahoo/Stooq data, SEC filings, Nasdaq symbol lists, Alpaca/IBKR execution workflows, and a US House transaction tracker. Its setup examples include a USD account budget and US-market assumptions; these were not carried over.

## Archive inventory

The 27 nested files comprise 11 skill guides, 11 Python programs, and five example/configuration files. The original scripts use Python's standard library and contain no test suite.

| Original skill | Python program | Size (bytes) | India adaptation in this project |
|---|---|---:|---|
| trader-scanner | `scan.py` | 47,679 | `scanner.py`, NSE/BSE exchange-aware scans on supplied bars |
| trader-news | `news.py` | 22,467 | `news.py`, official-link announcement CSV and keyword categories |
| trader-entry | `entry.py` | 42,324 | `entry.py`, completed-bar intraday ORB and daily swing confirmation |
| trader-exit | `exit.py` | 31,107 | `exit_planner.py`, INR stop/target/R multiple and trailing reference |
| trader-timemachine | `timemachine.py` | 43,070 | `backtest.py`, intraday/swing simulation, fees, slippage, drawdown |
| trader-risk | `check.py` | 39,151 | `risk.py`, cash, exposure, per-trade and daily paper limits |
| trader-budget | `size.py` | 39,238 | `budget.py`, INR sizing under risk, position, order, cash and cost caps |
| trader-broker | `ticket.py` | 32,390 | `paper_broker.py`, local simulated ledger only |
| trader-alerts | `alerts.py` | 32,825 | `alerts.py` and `calendar.py`, one-shot local checks in IST |
| trader-analyst | `facts.py` | 23,996 | `analyst.py`, sourced Indian results CSV ratios/trends |
| trader-pelosi | `ptr.py` | 22,928 | `disclosures.py`, Indian promoter/insider records |

The five other archived files are example/configuration files for the original budget, broker, alerts, and analyst skills. Their USD, Alpaca/Claude, and US-market data assumptions were replaced with INR JSON configuration, local paper state, and Indian disclosure formats.

## Behaviors checked during review

- Scanner patterns include prior 20-session high, bull flag, moving-average reclaim, RSI oversold/bounce, and opening-range breakout.
- Entry waits for completed bars and checks opening range or a supplied level, including volume confirmation behavior.
- Exit supports stop styles and R-multiple targets; the backtest resolves same-bar stop/target collisions conservatively as stop first.
- Budget selects the minimum among risk, cash, position and order limits; risk checks prevent unsupported order modes.
- Broker ticket logic in the original archive is a local safety gate/template and does not contain a usable live order connection. This project keeps paper fills separate from SmartAPI data access.
- News, fundamentals, alerts and disclosures relied on US feeds/schemas or local workflows that require Indian-source adapters.
