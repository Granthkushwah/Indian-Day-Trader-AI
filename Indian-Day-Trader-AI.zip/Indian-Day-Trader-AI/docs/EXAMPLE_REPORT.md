# Example system report (no market data loaded)

**Generated:** local run time (IST)  
**Mode:** paper only  
**Exchange:** NSE + BSE supported  
**Market data:** not configured  
**Signal:** none; no data was supplied  
**Risk:** INR limits loaded from configuration  
**Live order placement:** unavailable by design

This example shows the report shape without inventing prices, trades, or performance. A real scan report includes each row's exchange, symbol, bar timestamp, setup name, inputs, and data-source field. No signal is emitted for a symbol without valid supplied/authorized bars.
