# Local data formats

CSV files are UTF-8 with a header row. Decimal values use `.`; timestamps should include an offset or be Indian local time. No example rows with market prices are included.

## Candle bars (`data/bars.csv`)

Required columns: `timestamp,exchange,symbol,interval,open,high,low,close,volume`. Optional: `token,source`. Supported intervals include `1m`, `5m`, `15m`, `1d`. Times without an offset are interpreted as IST. Sort is normalized by the loader. Each row is one bar; do not mix adjusted and unadjusted prices in one test.

## SmartAPI instrument master

Use the official instrument reference JSON file. Run `python -m indian_trader.cli instruments-download --out data\angel_master.json` to fetch it, then use the `instruments` command to search. Angel One records commonly use fields `symbol`, `token`, `name`, `exch_seg`, `instrumenttype`, `lotsize`, and `tick_size`. The master is instrument metadata, not current price data.

## Groww instrument master

Run `python -m indian_trader.cli groww-instruments-download --out data\groww_instruments.csv` to fetch Groww's public instrument reference, then search it with `groww-instruments --file data\groww_instruments.csv --exchange NSE --segment CASH --query RELIANCE`. The API's `groww_symbol` field identifies the instrument for history requests, for example `NSE-RELIANCE`. This CSV is reference metadata, not price data.

## Announcements (`data/announcements.csv`)

Columns: `timestamp,exchange,symbol,category,title,url,source`. Keep the official filing URL and retrieval timestamp. Analyzer labels event categories by keywords only; it does not claim an event's likely price impact.

## Fundamentals (`data/financials.csv`)

Columns: `period_end,symbol,revenue,operating_income,net_income,eps,total_assets,total_debt,equity,source,url`. Optional: `market_price_inr,market_cap_inr`; optional financial values can be blank. The analyst compares sequential periods and, where four prior quarters exist, same-index year-over-year revenue. P/E and P/B are only calculated when corresponding price/market cap values are supplied. Ratios are arithmetic summaries, not valuation opinions. Use comparable reporting periods and note restatements/corporate actions.

## Disclosures (`data/disclosures.csv`)

Columns: `timestamp,exchange,symbol,disclosure_type,person_or_group,shares,holding_percent,change_percent,category,title,url,source`. This monitor lists records and flags large reported percentage changes; it does not infer intent, guilt, or a trading signal.

## Backtest conventions

CSV bars should be complete, exchange-local, and free from duplicate intervals. Intraday timestamps denote bar start times. The simulator enters no earlier than a subsequent bar after a completed signal. If a bar reaches both stop and target, stop is assumed first. Slippage and costs are applied. This conservative simplification still cannot model queue position, gaps, partial fills, impact, or all exchange/broker rules.
