# Usage guide

The commands below are offline unless stated. Replace file paths and symbols with your own licensed data. All prices and budgets are INR.

## Scan and entry

`python -m indian_trader.cli scan --file data\bars.csv --exchange NSE` runs the enabled daily/intraday scans on the supplied bars. `entry` checks one symbol and mode. Signal is a setup condition, not a recommendation.

## Plan exit and size

`exit` requires entry and stop, then calculates risk and target. `budget` estimates shares from equity, stop distance, slippage and configured fee assumptions. Review transaction-cost assumptions and actual liquidity.

## Paper orders

`paper-order` records a simulated immediate fill at the user-supplied reference price. This is not a broker execution or realistic fill guarantee. Ledger data is stored locally at `trader/paper_ledger.json`; use `paper-status` to view positions and simulated P&L.

## Backtest

`backtest --mode intraday` uses an opening-range breakout; `--mode swing` uses a 20-period high breakout. It reports number of trades, win rate, net P&L, average R and peak-to-trough drawdown. It applies configured slippage/fees but is not evidence of future results. Date-stamped point-in-time constituents and corporate-action adjusted prices are needed to address survivorship bias.

## Exchange data

For Angel One, dot-source `.\scripts\angelone_data_login.ps1`, then use `instruments-download`, `instruments`, `history`, and `quote`. For Groww, dot-source `.\scripts\groww_data_login.ps1`, then use `groww-instruments-download`, `groww-instruments`, `groww-history`, and `groww-quote`. Both adapters prompt locally and only read market data; never share credentials in chat. Groww's data endpoints may require an active plan entitlement. Offline CSV mode is the default. Neither adapter has an order endpoint.

## Skills

There is one `.agents/skills/trader-*/SKILL.md` for each original module. In Codex, invoke a skill by its name and specify the symbol, exchange, data file, timeframe and whether the request is intraday or swing. Skills instruct Codex to ask the local CLI for calculations and clearly state when the required data is missing.
