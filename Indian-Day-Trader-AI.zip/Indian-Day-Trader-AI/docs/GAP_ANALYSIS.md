# Gap analysis: US source to NSE/BSE paper research

The supplied guide and archive were inspected before implementation. The source ZIP contains 11 nested skills, 11 Python programs, and five example/config files. The original tools are standard-library based, but their market assumptions are US-specific.

| Original area | Original assumptions found | India adaptation | Status / limit |
|---|---|---|---|
| Scanner/universe | Nasdaq symbol directory; US ticker conventions; Yahoo charts | NSE/BSE exchange + symbol + instrument token; daily breakouts, flags, moving-average reclaim, RSI and opening range | Strategy calculations implemented on supplied OHLCV; no broad universe feed or fabricated symbols bundled |
| Market data | Unofficial Yahoo/Stooq endpoints | CSV source, Angel One and Groww instrument references, historical candles and quote REST adapters | Local login helpers and data calls are implemented; live account connectivity requires user setup and has not been tested; bulk Groww market download is not implemented |
| Sessions | New York time, DST, NYSE early-close rules | Fixed IST; regular cash session 09:15–15:30; separate exchange holiday configuration | Official NSE 2026 dates loaded; BSE calendar and later years remain unknown until verified; special sessions not inferred |
| News | Yahoo RSS and SEC 8-K | NSE/BSE corporate announcement links and user-imported records | Tagging and CSV review implemented; no scraping or unsupported sentiment claims |
| Fundamentals | SEC company facts, 10-Q/10-K, CIK | Indian quarterly results and statements from permitted exchange/company sources | CSV sequential/YoY metrics, margins, debt/equity, optional P/E and P/B implemented; no filing feed bundled |
| Pelosi tracker | US House PTR / STOCK Act | SEBI insider trading disclosures, promoter/shareholding changes, exchange announcements | Official-source CSV monitor implemented; it reports disclosures and does not infer intent |
| Entry/exit | US cash-session windows; long-only intraday | IST intraday ORB/level checks and swing trend confirmation; explicit stop/target/trailing level | Paper plan calculations implemented; no order advice or execution |
| Backtest | Yahoo intraday history; 60-day samples; stochastic replay | Bar-by-bar intraday and swing simulation, same-bar stop-first rule, slippage and charges | Implemented on input data; point-in-time universe/corporate actions are needed to assess survivorship bias |
| Budget/risk | USD fields, US day-trade/PDT assumptions, Alpaca order JSON | INR limits, cash-only, no leverage/short/options, daily loss/trade limits and charge estimates | Implemented conservatively; broker-specific charges are estimates and configurable |
| Broker | Alpaca/IBKR ticket and approval hand-off | Local simulated paper broker; Angel One and Groww data adapters remain separate | Paper order/position/P&L ledger implemented. Live order API deliberately absent |
| Alerts | US schedules/price polling | Local price, stop, target and IST session checks | One-shot local evaluation implemented; no background push service |
| Codex integration | Claude `${CLAUDE_SKILL_DIR}` and slash commands | `.agents/skills/trader-*/SKILL.md`, Windows-safe `python -m` commands | All 11 skill instructions included |
| Costs/data rights | US fees and public free endpoints | Configurable Indian brokerage, STT, stamp, SEBI, exchange charges; broker-authorized or licensed data only | Defaults are indicative and date-stamped; check official schedules before use |

## Inspected source behavior retained

- Scanner set-ups: 20-session closing high, bull flag, 20-session average reclaim, RSI oversold/bounce, and opening-range breakout.
- Entry logic: completed bars only, opening range/explicit level, and volume confirmation.
- Exit logic: opening-range or percentage/price/ATR-style stop concepts and R-multiple target.
- Time machine: historical replay with stop-first handling on bars where both stop and target touch.
- Risk/budget: size is constrained by risk, cash, order cap, portfolio exposure, and daily limits.
- Broker/alerts/news/fundamentals/disclosure: retain local safety gate, watch/alert logic, and record review, but replace US source schemas.

## Material limitations

This is a research and local simulation toolkit. It does not confirm account suitability, broker permission, exchange entitlements, current legal requirements, or guaranteed fills. It does not connect to live streaming or submit orders. Exchange holiday notices, levies, and broker tariffs change; the user must update configuration from official sources. Backtests can be biased by bad/incomplete bars, corporate actions, liquidity, survivorship, slippage, and fill assumptions.
