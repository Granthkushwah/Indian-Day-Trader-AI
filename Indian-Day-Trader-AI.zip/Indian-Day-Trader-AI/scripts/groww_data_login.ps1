$ErrorActionPreference = "Stop"

function Convert-SecureToPlainText {
    param([Parameter(Mandatory = $true)][System.Security.SecureString]$Value)
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    }
}

function Get-GrowwTokenFromApiKey {
    param(
        [Parameter(Mandatory = $true)][string]$ApiKey,
        [Parameter(Mandatory = $true)][string]$ApiSecret
    )

    $timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds().ToString()
    $sha256 = [Security.Cryptography.SHA256]::Create()
    try {
        $inputBytes = [Text.Encoding]::UTF8.GetBytes($ApiSecret + $timestamp)
        $checksum = [BitConverter]::ToString($sha256.ComputeHash($inputBytes)).Replace("-", "").ToLowerInvariant()
    }
    finally {
        $sha256.Dispose()
    }

    $body = @{
        key_type = "approval"
        checksum = $checksum
        timestamp = $timestamp
    } | ConvertTo-Json -Compress

    try {
        $response = Invoke-RestMethod `
            -Uri "https://api.groww.in/v1/token/api/access" `
            -Method Post `
            -Headers @{ Authorization = "Bearer $ApiKey"; Accept = "application/json"; "X-API-VERSION" = "1.0" } `
            -ContentType "application/json" `
            -Body $body
    }
    catch {
        throw "Groww token request failed. Check that today's approval is complete in Groww Cloud and that the API key/secret are correct. No credentials or token were saved to disk."
    }

    $token = $response.token
    if (-not $token -and $response.payload) { $token = $response.payload.token }
    if (-not $token -and $response.data) { $token = $response.data.token }
    if (-not $token) {
        throw "Groww did not return an access token. Check today's API approval and the Groww Cloud API key status. No credentials or token were saved to disk."
    }
    return [string]$token
}

Write-Host "Groww data login: credentials are entered locally and are not written to a file."
Write-Host "1 = Groww API Key + Secret (check/complete today's approval in Groww Cloud)"
Write-Host "2 = Access Token already generated in Groww"
$authChoice = Read-Host "Choose 1 or 2"

if ($authChoice -eq "1") {
    $apiKeySecure = Read-Host "Groww API key" -AsSecureString
    $apiSecretSecure = Read-Host "Groww API secret" -AsSecureString
    $apiKey = Convert-SecureToPlainText $apiKeySecure
    $apiSecret = Convert-SecureToPlainText $apiSecretSecure
    try {
        $accessToken = Get-GrowwTokenFromApiKey -ApiKey $apiKey -ApiSecret $apiSecret
    }
    finally {
        $apiKey = $null
        $apiSecret = $null
        $apiKeySecure.Dispose()
        $apiSecretSecure.Dispose()
    }
}
elseif ($authChoice -eq "2") {
    $tokenSecure = Read-Host "Groww access token" -AsSecureString
    try {
        $accessToken = Convert-SecureToPlainText $tokenSecure
    }
    finally {
        $tokenSecure.Dispose()
    }
    if (-not $accessToken) { throw "Access token cannot be blank." }
}
else {
    throw "Choose 1 or 2, then run the script again."
}

$env:GROWW_ACCESS_TOKEN = $accessToken
$accessToken = $null
Write-Host "Groww session is ready in this PowerShell window. The token was not printed or saved to disk."
Write-Host "This project uses the session only for Groww market-data GET requests; it has no Groww order-placement code."
Write-Host "When finished, clear it with: Remove-Item Env:GROWW_ACCESS_TOKEN -ErrorAction SilentlyContinue"
