# Run in the current PowerShell session with:
# . .\scripts\angelone_data_login.ps1
# This script authenticates for data access only. It never calls an order API.
$previousErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = "Stop"
$apiKeySecure = $null
$clientCodeSecure = $null
$pinSecure = $null
$totpSecure = $null
$plainApiKey = $null
$plainClientCode = $null
$plainPin = $null
$plainTotp = $null
$bodyJson = $null
$headers = $null
$response = $null
try {
    Write-Host "Finding this computer's network details for the SmartAPI request headers."
    Write-Host "The public-IP lookup sends only your public IP to api4.ipify.org; no Angel One credentials are sent to that site."
    $network = Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -and $_.IPv4Address } | Select-Object -First 1
    if (-not $network) { throw "Could not find an active network adapter." }
    $env:ANGELONE_LOCAL_IP = $network.IPv4Address[0].IPAddress
    $adapter = Get-NetAdapter -InterfaceIndex $network.InterfaceIndex | Select-Object -First 1
    if (-not $adapter) { throw "Could not find the active adapter's MAC address." }
    $env:ANGELONE_MAC_ADDRESS = $adapter.MacAddress
    $env:ANGELONE_PUBLIC_IP = ([string](Invoke-RestMethod -Uri "https://api4.ipify.org" -TimeoutSec 10)).Trim()

    $apiKeySecure = Read-Host "SmartAPI API key" -AsSecureString
    $clientCodeSecure = Read-Host "Angel One client code" -AsSecureString
    $pinSecure = Read-Host "Angel One PIN" -AsSecureString
    $totpSecure = Read-Host "Current 6-digit authenticator code (TOTP)" -AsSecureString
    $plainApiKey = [System.Net.NetworkCredential]::new('', $apiKeySecure).Password
    $plainClientCode = [System.Net.NetworkCredential]::new('', $clientCodeSecure).Password
    $plainPin = [System.Net.NetworkCredential]::new('', $pinSecure).Password
    $plainTotp = [System.Net.NetworkCredential]::new('', $totpSecure).Password

    $headers = @{
        "X-PrivateKey" = $plainApiKey
        "X-UserType" = "USER"
        "X-SourceID" = "WEB"
        "X-ClientLocalIP" = $env:ANGELONE_LOCAL_IP
        "X-ClientPublicIP" = $env:ANGELONE_PUBLIC_IP
        "X-MACAddress" = $env:ANGELONE_MAC_ADDRESS
        "Accept" = "application/json"
    }
    $bodyJson = @{ clientcode = $plainClientCode; password = $plainPin; totp = $plainTotp } | ConvertTo-Json -Compress
    $response = Invoke-RestMethod -Method Post `
        -Uri "https://apiconnect.angelone.in/rest/auth/angelbroking/user/v1/loginByPassword" `
        -Headers $headers -ContentType "application/json" -Body $bodyJson -TimeoutSec 20
    if (-not $response.status -or -not $response.data.jwtToken) {
        throw "Angel One did not return an access token. Check the API key, client code, PIN and current TOTP."
    }
    $env:ANGELONE_API_KEY = $plainApiKey
    $env:ANGELONE_ACCESS_TOKEN = [string]$response.data.jwtToken
    Write-Host "Data-only SmartAPI session is ready in this PowerShell window. The access token was not printed or saved to disk."
    Write-Host "Use it now for the project's history or quote command. Close this PowerShell window or clear ANGELONE_API_KEY and ANGELONE_ACCESS_TOKEN when done."
}
catch {
    $env:ANGELONE_API_KEY = $null
    $env:ANGELONE_ACCESS_TOKEN = $null
    throw "SmartAPI data login failed. No credentials or token were saved to disk. Check the network and SmartAPI details, then try again."
}
finally {
    $apiKeySecure = $null
    $clientCodeSecure = $null
    $pinSecure = $null
    $totpSecure = $null
    $plainApiKey = $null
    $plainClientCode = $null
    $plainPin = $null
    $plainTotp = $null
    $bodyJson = $null
    $headers = $null
    $response = $null
    $ErrorActionPreference = $previousErrorActionPreference
    $previousErrorActionPreference = $null
}
