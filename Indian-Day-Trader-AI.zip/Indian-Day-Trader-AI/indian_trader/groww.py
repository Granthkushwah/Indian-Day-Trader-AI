"""Read-only Groww market-data adapter. No order endpoints or methods exist here."""
import csv
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from .data import IST, parse_timestamp, write_bars
from .models import Candle

BASE_URL = "https://api.groww.in"
INSTRUMENTS_URL = "https://growwapi-assets.groww.in/instruments/instrument.csv"
INTERVALS = {
    "1M": ("1minute", "1m"),
    "2M": ("2minute", "2m"),
    "3M": ("3minute", "3m"),
    "5M": ("5minute", "5m"),
    "10M": ("10minute", "10m"),
    "15M": ("15minute", "15m"),
    "30M": ("30minute", "30m"),
    "1H": ("1hour", "1h"),
    "4H": ("4hour", "4h"),
    "1D": ("1day", "1d"),
    "1W": ("1week", "1w"),
    "1MONTH": ("1month", "1month"),
}


class GrowwApiError(RuntimeError):
    pass


class GrowwDataClient:
    def __init__(self, access_token=None, base_url=BASE_URL, timeout=20, min_request_interval_sec=0.25):
        self.access_token = access_token or os.environ.get("GROWW_ACCESS_TOKEN")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.min_request_interval_sec = float(min_request_interval_sec)
        self._last_request_monotonic = None

    def _headers(self):
        if not self.access_token:
            raise GrowwApiError("Start a local Groww session first with . .\\scripts\\groww_data_login.ps1. Never put the token in chat or a file.")
        return {"Accept": "application/json", "Authorization": "Bearer {}".format(self.access_token),
                "X-API-VERSION": "1.0"}

    def _get(self, path, params):
        if self._last_request_monotonic is not None:
            delay = self.min_request_interval_sec - (time.monotonic() - self._last_request_monotonic)
            if delay > 0:
                time.sleep(delay)
        url = self.base_url + path + "?" + urlencode(params)
        request = Request(url, headers=self._headers(), method="GET")
        self._last_request_monotonic = time.monotonic()
        try:
            with urlopen(request, timeout=self.timeout) as response:
                result = json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            raise GrowwApiError("Groww API returned HTTP {}. Check the access token, API plan, symbol, and request limits.".format(exc.code))
        except URLError as exc:
            raise GrowwApiError("Could not reach Groww API: {}".format(exc.reason))
        except (ValueError, OSError) as exc:
            raise GrowwApiError("Groww API response could not be read: {}".format(exc))
        if str(result.get("status", "")).upper() != "SUCCESS":
            error = result.get("error") or {}
            message = error.get("message") if isinstance(error, dict) else None
            message = message or result.get("message") or "request was rejected"
            raise GrowwApiError("Groww API request failed: {}".format(message))
        return result.get("payload") or {}

    def history(self, exchange, symbol, interval, from_date, to_date, segment="CASH"):
        exchange = exchange.upper()
        segment = segment.upper()
        key = interval.upper()
        if exchange not in ("NSE", "BSE"):
            raise ValueError("exchange must be NSE or BSE")
        if segment not in ("CASH", "FNO"):
            raise ValueError("segment must be CASH or FNO")
        if key not in INTERVALS:
            raise ValueError("unsupported interval; choose one of: {}".format(", ".join(INTERVALS)))
        if not symbol or not symbol.strip():
            raise ValueError("Groww symbol is required")
        symbol = symbol.strip().upper()
        groww_symbol = symbol if symbol.startswith(("NSE-", "BSE-")) else "{}-{}".format(exchange, symbol)
        api_interval, output_interval = INTERVALS[key]
        params = {"exchange": exchange, "segment": segment, "groww_symbol": groww_symbol,
                  "start_time": from_date, "end_time": to_date, "candle_interval": api_interval}
        payload = self._get("/v1/historical/candles", params)
        bars = []
        for row in payload.get("candles") or []:
            if len(row) < 6:
                continue
            timestamp = row[0]
            if isinstance(timestamp, (int, float)):
                timestamp = datetime.fromtimestamp(float(timestamp), tz=timezone.utc).astimezone(IST).isoformat()
            bars.append(Candle(timestamp=parse_timestamp(str(timestamp)), exchange=exchange,
                               symbol=groww_symbol, interval=output_interval,
                               open=float(row[1]), high=float(row[2]), low=float(row[3]), close=float(row[4]),
                               volume=float(row[5]), source="GrowwAPI").validate())
        return bars

    def quote(self, exchange, symbol, segment="CASH"):
        exchange = exchange.upper()
        segment = segment.upper()
        if exchange not in ("NSE", "BSE"):
            raise ValueError("exchange must be NSE or BSE")
        if segment not in ("CASH", "FNO"):
            raise ValueError("segment must be CASH or FNO")
        if not symbol or not symbol.strip():
            raise ValueError("trading symbol is required")
        return self._get("/v1/live-data/quote", {"exchange": exchange, "segment": segment,
                                                   "trading_symbol": symbol.strip().upper()})


def save_history(client, exchange, symbol, interval, from_date, to_date, output, segment="CASH"):
    bars = client.history(exchange, symbol, interval, from_date, to_date, segment=segment)
    write_bars(output, bars)
    return bars


def download_instruments(output):
    request = Request(INSTRUMENTS_URL, headers={"Accept": "text/csv"}, method="GET")
    try:
        with urlopen(request, timeout=30) as response:
            content = response.read()
    except HTTPError as exc:
        raise GrowwApiError("Groww instruments download returned HTTP {}.".format(exc.code))
    except URLError as exc:
        raise GrowwApiError("Could not reach Groww instruments: {}".format(exc.reason))
    if not content.strip():
        raise GrowwApiError("Groww instruments file was empty")
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    return {"saved": str(target), "bytes": len(content), "source": "Groww official instrument CSV"}


def search_instruments(path, query="", exchange=None, segment="CASH", limit=50):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError("Groww instruments CSV not found: {}".format(path))
    query = (query or "").strip().casefold()
    exchange = exchange.upper() if exchange else None
    segment = segment.upper() if segment else None
    if exchange and exchange not in ("NSE", "BSE"):
        raise ValueError("exchange must be NSE or BSE")
    if segment and segment not in ("CASH", "FNO"):
        raise ValueError("segment must be CASH or FNO")
    if limit < 1:
        raise ValueError("limit must be positive")
    matches = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        required = {"exchange", "trading_symbol", "groww_symbol", "name", "segment", "instrument_type"}
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError("Groww instrument file is missing columns: {}".format(", ".join(sorted(missing))))
        for row in reader:
            if exchange and row.get("exchange", "").upper() != exchange:
                continue
            if segment and row.get("segment", "").upper() != segment:
                continue
            haystack = " ".join((row.get("trading_symbol", ""), row.get("groww_symbol", ""), row.get("name", ""))).casefold()
            if query and query not in haystack:
                continue
            matches.append({key: row.get(key, "") for key in (
                "exchange", "trading_symbol", "groww_symbol", "name", "instrument_type", "segment", "series")})
            if len(matches) >= limit:
                break
    return {"count": len(matches), "instruments": matches}
