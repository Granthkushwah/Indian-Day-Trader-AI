import csv
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List

from .models import Candle

IST = timezone(timedelta(hours=5, minutes=30), name="IST")
REQUIRED_BAR_COLUMNS = {"timestamp", "exchange", "symbol", "interval", "open", "high", "low", "close", "volume"}


def parse_timestamp(value):
    value = (value or "").strip()
    if not value:
        raise ValueError("timestamp is blank")
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    parsed = datetime.fromisoformat(value)
    return parsed.replace(tzinfo=IST) if parsed.tzinfo is None else parsed.astimezone(IST)


def load_bars(path, exchange=None, symbol=None, interval=None):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError("Bar CSV not found: {}".format(path))
    candles = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = REQUIRED_BAR_COLUMNS.difference(reader.fieldnames or [])
        if missing:
            raise ValueError("Missing candle columns: {}".format(", ".join(sorted(missing))))
        for number, row in enumerate(reader, start=2):
            try:
                candle = Candle(
                    timestamp=parse_timestamp(row["timestamp"]),
                    exchange=row["exchange"].strip().upper(),
                    symbol=row["symbol"].strip().upper(),
                    interval=row["interval"].strip().lower(),
                    open=float(row["open"]), high=float(row["high"]),
                    low=float(row["low"]), close=float(row["close"]),
                    volume=float(row["volume"]), token=(row.get("token") or "").strip(),
                    source=(row.get("source") or "CSV").strip() or "CSV",
                ).validate()
            except Exception as exc:
                raise ValueError("Invalid CSV row {}: {}".format(number, exc))
            if exchange and candle.exchange != exchange.upper():
                continue
            if symbol and candle.symbol != symbol.upper():
                continue
            if interval and candle.interval != interval.lower():
                continue
            candles.append(candle)
    return sorted(candles, key=lambda candle: (candle.exchange, candle.symbol, candle.interval, candle.timestamp))


def write_bars(path, candles):
    columns = ["timestamp", "exchange", "symbol", "interval", "open", "high", "low", "close", "volume", "token", "source"]
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for candle in candles:
            writer.writerow(candle.as_dict())
    return path


class CsvMarketData:
    """Offline source for user-provided, licensed OHLCV files."""

    def candles(self, path, exchange=None, symbol=None, interval=None):
        return load_bars(path, exchange=exchange, symbol=symbol, interval=interval)
