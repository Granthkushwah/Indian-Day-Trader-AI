"""Angel One data-only REST adapter. No order endpoints or order methods exist here."""
import json
import os
import time
from datetime import datetime
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .data import parse_timestamp, write_bars
from .models import Candle

BASE_URL = "https://apiconnect.angelone.in"


class SmartApiError(RuntimeError):
    pass


class SmartApiClient:
    def __init__(self, api_key=None, access_token=None, base_url=BASE_URL, timeout=20, min_request_interval_sec=1.0):
        self.api_key = api_key or os.environ.get("ANGELONE_API_KEY")
        self.access_token = access_token or os.environ.get("ANGELONE_ACCESS_TOKEN")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.min_request_interval_sec = float(min_request_interval_sec)
        self._last_request_monotonic = None

    def _headers(self):
        if not self.api_key or not self.access_token:
            raise SmartApiError("Set ANGELONE_API_KEY and ANGELONE_ACCESS_TOKEN locally; never place them in chat or config files.")
        return {"Content-Type": "application/json", "Accept": "application/json", "X-PrivateKey": self.api_key,
                "Authorization": "Bearer {}".format(self.access_token), "X-SourceID": "WEB",
                "X-UserType": "USER", "X-ClientLocalIP": os.environ.get("ANGELONE_LOCAL_IP", "127.0.0.1"),
                "X-ClientPublicIP": os.environ.get("ANGELONE_PUBLIC_IP", "127.0.0.1"),
                "X-MACAddress": os.environ.get("ANGELONE_MAC_ADDRESS", "00:00:00:00:00:00")}

    def _post(self, path, body):
        if self._last_request_monotonic is not None:
            elapsed = time.monotonic() - self._last_request_monotonic
            delay = self.min_request_interval_sec - elapsed
            if delay > 0:
                time.sleep(delay)
        payload = json.dumps(body).encode("utf-8")
        headers = self._headers()
        request = Request(self.base_url + path, data=payload, headers=headers, method="POST")
        self._last_request_monotonic = time.monotonic()
        try:
            with urlopen(request, timeout=self.timeout) as response:
                result = json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            raise SmartApiError("SmartAPI returned HTTP {}. Check account authorization, token and current API documentation.".format(exc.code))
        except URLError as exc:
            raise SmartApiError("Could not reach SmartAPI: {}".format(exc.reason))
        except (ValueError, OSError) as exc:
            raise SmartApiError("SmartAPI response could not be read: {}".format(exc))
        if not result.get("status"):
            raise SmartApiError("SmartAPI request was rejected: {}".format(result.get("message", "unknown error")))
        return result

    def history(self, exchange, token, interval, from_date, to_date, symbol):
        exchange, interval = exchange.upper(), interval.upper()
        if exchange not in ("NSE", "BSE"):
            raise ValueError("exchange must be NSE or BSE")
        allowed = {"ONE_MINUTE", "FIVE_MINUTE", "FIFTEEN_MINUTE", "ONE_DAY"}
        interval = {"1M": "ONE_MINUTE", "5M": "FIVE_MINUTE", "15M": "FIFTEEN_MINUTE", "1D": "ONE_DAY"}.get(interval, interval)
        if interval not in allowed:
            raise ValueError("unsupported interval; use 1m, 5m, 15m, 1d")
        body = {"exchange": exchange, "symboltoken": str(token), "interval": interval,
                "fromdate": from_date, "todate": to_date}
        response = self._post("/rest/secure/angelbroking/historical/v1/getCandleData", body)
        interval_label = {"ONE_MINUTE": "1m", "FIVE_MINUTE": "5m", "FIFTEEN_MINUTE": "15m", "ONE_DAY": "1d"}[interval]
        bars = []
        for row in response.get("data") or []:
            if len(row) < 6:
                continue
            bars.append(Candle(timestamp=parse_timestamp(row[0]),
                               exchange=exchange, symbol=symbol.upper(), interval=interval_label,
                               open=float(row[1]), high=float(row[2]), low=float(row[3]), close=float(row[4]),
                               volume=float(row[5]), token=str(token), source="AngelOneSmartAPI").validate())
        return bars

    def quote(self, exchange, token):
        exchange = exchange.upper()
        if exchange not in ("NSE", "BSE"):
            raise ValueError("exchange must be NSE or BSE")
        result = self._post("/rest/secure/angelbroking/market/v1/quote/", {"mode": "LTP", "exchangeTokens": {exchange: [str(token)]}})
        return result.get("data")


def save_history(client, exchange, token, interval, from_date, to_date, symbol, output):
    bars = client.history(exchange, token, interval, from_date, to_date, symbol)
    write_bars(output, bars)
    return bars
