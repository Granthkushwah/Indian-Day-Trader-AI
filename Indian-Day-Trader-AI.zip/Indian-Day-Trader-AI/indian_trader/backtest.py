from collections import defaultdict

from .config import load_json
from .costs import estimate_order_charges
from .indicators import atr


def _metrics(trades, initial_equity):
    equity = float(initial_equity)
    peak = equity
    max_drawdown = 0.0
    for trade in trades:
        equity += trade["net_pnl_inr"]
        peak = max(peak, equity)
        if peak:
            max_drawdown = max(max_drawdown, (peak - equity) / peak)
    wins = [trade for trade in trades if trade["net_pnl_inr"] > 0]
    return {"trade_count": len(trades), "win_rate": len(wins) / len(trades) if trades else 0.0,
            "net_pnl_inr": round(sum(trade["net_pnl_inr"] for trade in trades), 2),
            "average_r": (sum(trade["net_r"] for trade in trades) / len(trades)) if trades else 0.0,
            "maximum_drawdown_pct": round(max_drawdown * 100, 2), "ending_equity_inr": round(equity, 2)}


def run_backtest(candles, symbol, exchange, mode="intraday", initial_equity=100000, risk_reward=2.0,
                 config=None, fees_config=None, slippage_bps=None):
    risk_config = config or load_json("risk_config.json", {})
    fees_config = fees_config or load_json("fees_config.json", {})
    bars = [bar for bar in candles if bar.symbol == symbol.upper() and bar.exchange == exchange.upper()]
    bars.sort(key=lambda bar: bar.timestamp)
    if mode == "intraday":
        bars = [bar for bar in bars if bar.interval in ("1m", "5m", "15m")]
        intervals = set(bar.interval for bar in bars)
        if len(intervals) > 1:
            raise ValueError("Use one intraday interval per backtest file; mixed 1m/5m/15m bars can distort signals")
    elif mode == "swing":
        bars = [bar for bar in bars if bar.interval == "1d"]
    else:
        raise ValueError("mode must be intraday or swing")
    if len(bars) < 2:
        return {"status": "INSUFFICIENT_DATA", "symbol": symbol.upper(), "mode": mode, "trades": [], **_metrics([], initial_equity)}
    slip = float(slippage_bps if slippage_bps is not None else fees_config.get("slippage_bps", 5)) / 10000.0
    trade_config = fees_config
    trades = []
    occupied_until = -1
    groups = defaultdict(list)
    for index, bar in enumerate(bars):
        groups[bar.timestamp.date()].append((index, bar))
    if mode == "intraday":
        for day_items in groups.values():
            day_indices = [item[0] for item in day_items]
            day_bars = [item[1] for item in day_items]
            opening = [bar for bar in day_bars if (9, 15) <= (bar.timestamp.hour, bar.timestamp.minute) < (9, 30)]
            if not opening:
                continue
            range_high = max(bar.high for bar in opening)
            range_low = min(bar.low for bar in opening)
            average_opening_volume = sum(bar.volume for bar in opening) / float(len(opening))
            start_index = day_indices[0]
            signal_index = next((idx for idx in day_indices if bars[idx].timestamp.time() >= bars[idx].timestamp.replace(hour=9, minute=30).time()
                                 and bars[idx].close > range_high
                                 and (average_opening_volume <= 0 or bars[idx].volume / average_opening_volume >= 1.0)), None)
            if signal_index is None or signal_index + 1 >= day_indices[-1] + 1:
                continue
            entry_index = signal_index + 1
            entry_price = bars[entry_index].open * (1 + slip)
            stop_price = min(range_low, entry_price * 0.995)
            if stop_price <= 0 or stop_price >= entry_price:
                continue
            target = entry_price + (entry_price - stop_price) * float(risk_reward)
            exit_index, exit_price, reason = day_indices[-1], bars[day_indices[-1]].close, "session_close"
            for idx in day_indices[entry_index - start_index:]:
                bar = bars[idx]
                if bar.low <= stop_price:
                    exit_index, exit_price, reason = idx, stop_price * (1 - slip), "stop"
                    break
                if bar.high >= target:
                    exit_index, exit_price, reason = idx, target * (1 - slip), "target"
                    break
            trade = _make_trade(bars[signal_index], entry_price, exit_price, stop_price, target,
                                exit_index, reason, risk_config, trade_config, exchange, mode, initial_equity, slip)
            if trade:
                trades.append(trade)
    else:
        index = 20
        while index < len(bars) - 1:
            prior_high = max(bar.high for bar in bars[index-20:index])
            signal = bars[index]
            if signal.close <= prior_high:
                index += 1
                continue
            entry_index = index + 1
            entry_price = bars[entry_index].open * (1 + slip)
            vol = atr(bars[:index+1], 14)
            stop_price = entry_price - (vol if vol and vol > 0 else entry_price * 0.02)
            target = entry_price + (entry_price - stop_price) * float(risk_reward)
            exit_index, exit_price, reason = len(bars) - 1, bars[-1].close * (1 - slip), "end_of_data"
            for idx in range(entry_index, len(bars)):
                bar = bars[idx]
                if bar.low <= stop_price:
                    exit_index, exit_price, reason = idx, stop_price * (1 - slip), "stop"
                    break
                if bar.high >= target:
                    exit_index, exit_price, reason = idx, target * (1 - slip), "target"
                    break
            trade = _make_trade(signal, entry_price, exit_price, stop_price, target,
                                exit_index, reason, risk_config, trade_config, exchange, mode, initial_equity, slip)
            if trade:
                trades.append(trade)
            index = exit_index + 1
    transaction_rate = fees_config.get("rates", {}).get("transaction_rate_by_exchange", {}).get(exchange.upper())
    return {"status": "OK", "symbol": symbol.upper(), "exchange": exchange.upper(), "mode": mode,
            "data_rows": len(bars), "source": "user_supplied_bars", "slippage_bps_each_side": slippage_bps if slippage_bps is not None else fees_config.get("slippage_bps", 5),
            "fee_estimate_complete": transaction_rate is not None,
            "survivorship_bias_control": False, "limitations": ["No point-in-time universe was supplied.", "No queue/partial-fill or market-impact model.", "Backtest is hypothetical, not a forecast."],
            **_metrics(trades, initial_equity), "trades": trades}


def _make_trade(signal, entry, exit_price, stop, target, exit_index, reason, risk_config, fees_config, exchange, mode, equity, slip_fraction):
    risk_per_share = entry - stop
    risk_cap = min(float(risk_config.get("max_loss_per_trade_inr", 500)), float(equity) * float(risk_config.get("risk_pct_per_trade", 0.005)))
    if risk_per_share <= 0:
        return None
    quantity = min(int(risk_cap // risk_per_share), int(float(equity) * float(risk_config.get("max_position_pct", 0.25)) // entry),
                   int(float(risk_config.get("max_order_value_inr", equity)) // entry),
                   int(float(equity) * (1 - float(risk_config.get("cash_buffer_pct", 0.1))) // entry))
    estimate = None
    while quantity > 0:
        entry_estimate = estimate_order_charges(entry * quantity, "BUY", exchange, mode, fees_config)
        stop_estimate = estimate_order_charges(stop * quantity, "SELL", exchange, mode, fees_config)
        estimate = quantity * risk_per_share + (entry + stop) * quantity * slip_fraction + entry_estimate["estimated_total_inr"] + stop_estimate["estimated_total_inr"]
        if estimate <= risk_cap:
            break
        quantity -= 1
    if quantity < 1:
        return None
    gross = (exit_price - entry) * quantity
    entry_cost = estimate_order_charges(entry * quantity, "BUY", exchange, mode, fees_config)
    exit_cost = estimate_order_charges(exit_price * quantity, "SELL", exchange, mode, fees_config)
    total_cost = entry_cost["estimated_total_inr"] + exit_cost["estimated_total_inr"]
    net = gross - total_cost
    return {"signal_time": signal.timestamp.isoformat(), "entry_time_ordered_after_signal": True,
            "exit_bar_index": exit_index, "entry_inr": round(entry, 4), "exit_inr": round(exit_price, 4),
            "stop_inr": round(stop, 4), "target_inr": round(target, 4), "quantity": quantity,
            "estimated_risk_including_costs_inr": round(estimate, 2),
            "exit_reason": reason, "gross_pnl_inr": round(gross, 2), "estimated_costs_inr": round(total_cost, 2),
            "net_pnl_inr": round(net, 2), "net_r": round(net / max(1e-12, risk_per_share * quantity), 4),
            "same_bar_stop_first": True}
