import csv
from pathlib import Path


NUMERIC_FIELDS = ("revenue", "operating_income", "net_income", "eps", "total_assets", "total_debt", "equity")


def analyze_financials(path, symbol):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError("Financials CSV not found: {}".format(path))
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        required = {"period_end", "symbol", "source", "url"}.union(NUMERIC_FIELDS)
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError("Missing financial columns: {}".format(", ".join(sorted(missing))))
        rows = [row for row in reader if row["symbol"].upper() == symbol.upper()]
    rows.sort(key=lambda item: item["period_end"])
    if not rows:
        return {"symbol": symbol.upper(), "status": "NO_DATA", "periods": []}
    periods = []
    previous = None
    for index, row in enumerate(rows):
        values = {}
        for field in NUMERIC_FIELDS:
            values[field] = float(row[field]) if row.get(field, "").strip() else None
        growth = None
        if previous and values["revenue"] is not None and previous["revenue"] not in (None, 0):
            growth = values["revenue"] / previous["revenue"] - 1.0
        yoy_growth = None
        if index >= 4:
            prior_row = rows[index - 4]
            prior_revenue = float(prior_row["revenue"]) if prior_row.get("revenue", "").strip() else None
            if values["revenue"] is not None and prior_revenue not in (None, 0):
                yoy_growth = values["revenue"] / prior_revenue - 1.0
        operating_margin = (values["operating_income"] / values["revenue"]
                            if values["operating_income"] is not None and values["revenue"] not in (None, 0) else None)
        net_margin = (values["net_income"] / values["revenue"]
                      if values["net_income"] is not None and values["revenue"] not in (None, 0) else None)
        debt_equity = (values["total_debt"] / values["equity"]
                       if values["total_debt"] is not None and values["equity"] not in (None, 0) else None)
        market_price = float(row["market_price_inr"]) if row.get("market_price_inr", "").strip() else None
        market_cap = float(row["market_cap_inr"]) if row.get("market_cap_inr", "").strip() else None
        pe = market_price / values["eps"] if market_price is not None and values["eps"] not in (None, 0) and values["eps"] > 0 else None
        price_to_book = market_cap / values["equity"] if market_cap is not None and values["equity"] not in (None, 0) and values["equity"] > 0 else None
        periods.append({"period_end": row["period_end"], "values_inr_or_reported_unit": values,
                        "sequential_revenue_growth": growth, "year_over_year_revenue_growth": yoy_growth,
                        "operating_margin": operating_margin, "net_margin": net_margin, "debt_to_equity": debt_equity,
                        "valuation": {"price_to_earnings": pe, "price_to_book": price_to_book,
                                      "market_price_inr": market_price, "market_cap_inr": market_cap},
                        "source": row["source"], "url": row["url"]})
        previous = values
    return {"symbol": symbol.upper(), "status": "OK", "periods": periods,
            "note": "Reported values retain the source unit; sequential comparisons require comparable periods."}
