import json
from pathlib import Path
import gzip
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

MASTER_URL = "https://margincalculator.angelone.in/OpenAPI_File/files/OpenAPIScripMaster.json"


def _master_rows(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("data", "instruments", "records"):
            if isinstance(data.get(key), list):
                return data[key]
    raise ValueError("Instrument master must be a list or contain a data/instruments/records list")


def download_master(path, url=MASTER_URL, timeout=30):
    """Download Angel One's public instrument reference file; this is not price data."""
    request = Request(url, headers={"User-Agent": "Indian-Day-Trader-AI/0.1", "Accept": "application/json"})
    try:
        with urlopen(request, timeout=timeout) as response:
            content = response.read()
            if response.headers.get("Content-Encoding", "").lower() == "gzip" or content[:2] == b"\x1f\x8b":
                content = gzip.decompress(content)
    except HTTPError as exc:
        raise RuntimeError("Angel One instrument master download returned HTTP {}. Try again later or use the official file manually.".format(exc.code))
    except URLError as exc:
        raise RuntimeError("Could not reach the Angel One instrument master: {}".format(exc.reason))
    try:
        data = json.loads(content.decode("utf-8-sig"))
        rows = _master_rows(data)
    except (UnicodeDecodeError, ValueError) as exc:
        raise RuntimeError("The downloaded instrument master was not valid JSON: {}".format(exc))
    if not rows:
        raise RuntimeError("Angel One instrument master was empty")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return {"path": str(path), "record_count": len(rows), "source": url}


def normalize_exchange(value):
    value = str(value or "").strip().upper()
    if value in ("NSE", "NSE_CM", "NSECM"):
        return "NSE"
    if value in ("BSE", "BSE_CM", "BSECM"):
        return "BSE"
    return value


def search_master(path, query, exchange=None, limit=50):
    path = Path(path)
    with path.open("r", encoding="utf-8") as handle:
        rows = _master_rows(json.load(handle))
    query = query.strip().upper()
    hits = []
    for row in rows:
        symbol = str(row.get("symbol", row.get("tradingsymbol", ""))).upper()
        name = str(row.get("name", "")).upper()
        exch = normalize_exchange(row.get("exch_seg", row.get("exchange", "")))
        if exchange and exch != normalize_exchange(exchange):
            continue
        if query and query not in symbol and query not in name:
            continue
        hits.append({"exchange": exch, "symbol": symbol, "name": name,
                     "token": str(row.get("token", row.get("symboltoken", ""))),
                     "instrument_type": row.get("instrumenttype", row.get("instrument_type", "")),
                     "tick_size": row.get("tick_size", ""), "lot_size": row.get("lotsize", row.get("lot_size", ""))})
        if len(hits) >= limit:
            break
    return hits
