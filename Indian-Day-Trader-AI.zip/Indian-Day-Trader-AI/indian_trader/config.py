import json
from pathlib import Path

IST_OFFSET_MINUTES = 330


def project_root():
    return Path(__file__).resolve().parent.parent


def load_json(name, default=None):
    path = project_root() / "config" / name
    if not path.exists():
        return default if default is not None else {}
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    with temp_path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False)
    temp_path.replace(path)
