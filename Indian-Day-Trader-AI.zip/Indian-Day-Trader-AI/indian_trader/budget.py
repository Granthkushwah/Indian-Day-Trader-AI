from .config import load_json
from .costs import estimate_order_charges


def size_position(entry, stop, equity, config=None, exchange="NSE", mode="intraday"):
    config = config or load_json("risk_config.json", {})
    entry, stop, equity = float(entry), float(stop), float(equity)
    if entry <= 0 or stop <= 0 or stop >= entry or equity <= 0:
        raise ValueError("entry, equity must be positive and stop must be below entry")
    risk_per_share = entry - stop
    risk_cap = min(float(config.get("max_loss_per_trade_inr", 500)), equity * float(config.get("risk_pct_per_trade", 0.005)))
    by_risk = int(risk_cap // risk_per_share)
    cash = equity * (1.0 - float(config.get("cash_buffer_pct", 0.1)))
    position_cap = equity * float(config.get("max_position_pct", 0.25))
    order_cap = float(config.get("max_order_value_inr", 100000))
    quantity = max(0, min(by_risk, int(cash // entry), int(position_cap // entry), int(order_cap // entry)))
    fees_config = load_json("fees_config.json", {})
    slip_fraction = float(fees_config.get("slippage_bps", 5)) / 10000.0
    estimate = None
    while quantity > 0:
        entry_cost = estimate_order_charges(entry * quantity, "BUY", exchange, mode, fees_config)
        stop_cost = estimate_order_charges(stop * quantity, "SELL", exchange, mode, fees_config)
        estimated_total_costs = entry_cost["estimated_total_inr"] + stop_cost["estimated_total_inr"]
        estimated_loss = quantity * risk_per_share + quantity * (entry + stop) * slip_fraction + estimated_total_costs
        if estimated_loss <= risk_cap:
            estimate = {"costs_inr": round(estimated_total_costs, 2), "slippage_inr": round(quantity * (entry + stop) * slip_fraction, 2),
                        "max_loss_including_estimated_costs_inr": round(estimated_loss, 2),
                        "fee_estimate_complete": entry_cost["estimate_complete"] and stop_cost["estimate_complete"]}
            break
        quantity -= 1
    value = quantity * entry
    return {"quantity": quantity, "entry_inr": round(entry, 2), "stop_inr": round(stop, 2),
            "position_value_inr": round(value, 2), "max_loss_at_stop_inr": round(quantity * risk_per_share, 2),
            "estimated_stop_costs": estimate,
            "limiting_share_count": {"risk": by_risk, "cash": int(cash // entry),
                                     "position_cap": int(position_cap // entry), "order_cap": int(order_cap // entry)},
            "exchange": exchange.upper(), "mode": mode.lower(), "paper_only": True}
