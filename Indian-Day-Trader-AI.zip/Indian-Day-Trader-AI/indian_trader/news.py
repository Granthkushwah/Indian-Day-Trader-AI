import csv
from pathlib import Path

KEYWORDS = {
    "earnings": ("results", "earnings", "quarterly", "financial result"),
    "management": ("resignation", "appointment", "director", "ceo", "cfo", "key managerial"),
    "corporate_action": ("dividend", "split", "buyback", "bonus", "rights issue", "merger", "acquisition"),
    "regulatory": ("sebi", "order", "penalty", "investigation", "regulatory", "show cause"),
    "fundraising": ("fund raise", "qip", "preferential", "placement", "issue of shares"),
    "operations": ("shutdown", "fire", "production", "plant", "contract", "order win"),
}


def classify(title):
    text = (title or "").lower()
    return [category for category, words in KEYWORDS.items() if any(word in text for word in words)] or ["general"]


def read_announcements(path, symbol=None):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError("Announcements CSV not found: {}".format(path))
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        required = {"timestamp", "exchange", "symbol", "category", "title", "url", "source"}
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError("Missing announcement columns: {}".format(", ".join(sorted(missing))))
        output = []
        for row in reader:
            if symbol and row["symbol"].upper() != symbol.upper():
                continue
            row["keyword_tags"] = classify(row["title"])
            row["impact"] = "not_assessed"
            output.append(row)
    return output
