def make_plan(entry, stop, risk_reward=2.0, trailing_percent=None):
    entry, stop, risk_reward = float(entry), float(stop), float(risk_reward)
    if entry <= 0 or stop <= 0 or stop >= entry:
        raise ValueError("Long paper plan requires a positive stop below entry")
    if risk_reward <= 0:
        raise ValueError("risk-reward must be positive")
    risk = entry - stop
    plan = {"entry_inr": round(entry, 2), "stop_inr": round(stop, 2), "risk_per_share_inr": round(risk, 2),
            "target_inr": round(entry + risk * risk_reward, 2), "risk_reward": risk_reward,
            "plan_type": "paper_only"}
    if trailing_percent is not None:
        if not 0 < float(trailing_percent) < 100:
            raise ValueError("trailing_percent must be between 0 and 100")
        plan["trailing_stop_reference_inr"] = round(entry * (1 - float(trailing_percent) / 100.0), 2)
        plan["trailing_percent"] = float(trailing_percent)
    return plan
