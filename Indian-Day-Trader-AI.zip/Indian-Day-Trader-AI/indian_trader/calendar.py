from datetime import date, datetime, time, timedelta

from .data import IST
from .config import load_json


def market_config():
    return load_json("market_config.json", {})


def is_session_day(day, exchange="NSE", config=None):
    if isinstance(day, datetime):
        day = day.astimezone(IST).date()
    elif isinstance(day, str):
        day = date.fromisoformat(day[:10])
    exchange = exchange.upper()
    config = config or market_config()
    if day.weekday() >= 5:
        return False
    holiday_data = config.get("holidays", {}).get(exchange, {})
    if not holiday_data.get("verified", False):
        return None
    if holiday_data.get("year") != day.year:
        return None
    return day.isoformat() not in set(holiday_data.get("dates", []))


def session_state(now=None, exchange="NSE", config=None):
    config = config or market_config()
    now = now or datetime.now(IST)
    now = now.astimezone(IST)
    day_state = is_session_day(now.date(), exchange, config)
    schedule = config.get("regular_session", {})
    start = time.fromisoformat(schedule.get("open", "09:15"))
    end = time.fromisoformat(schedule.get("close", "15:30"))
    local_time = now.time().replace(tzinfo=None)
    open_now = bool(day_state is True and start <= local_time <= end)
    if day_state is False:
        label = "closed_weekend_or_verified_holiday"
    elif day_state is None:
        label = "unknown_holiday_calendar"
    elif open_now:
        label = "regular_session"
    else:
        label = "outside_regular_session"
    return {"exchange": exchange.upper(), "time_ist": now.isoformat(), "session": label,
            "open": open_now, "regular_open": start.isoformat(), "regular_close": end.isoformat(),
            "holiday_calendar_verified": day_state is not None}
