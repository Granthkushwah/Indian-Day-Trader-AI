from .config import load_json
from .costs import estimate_order_charges


def check_order(order, config=None, ledger=None):
    config = config or load_json("risk_config.json", {})
    reasons = []
    if order.get("mode") not in ("intraday", "swing"):
        reasons.append("mode must be intraday or swing")
    if order.get("exchange", "").upper() not in ("NSE", "BSE"):
        reasons.append("exchange must be NSE or BSE")
    if order.get("side", "").upper() != "BUY":
        reasons.append("short selling and sell-to-open are disabled")
    try:
        qty, entry, stop = int(order["quantity"]), float(order["entry"]), float(order["stop"])
        if not order.get("symbol"):
            reasons.append("symbol is required")
        if qty <= 0 or entry <= 0 or stop <= 0 or stop >= entry:
            reasons.append("quantity/entry invalid or required stop is not below entry")
        if float(order.get("equity", config.get("paper_equity_inr", 100000))) <= 0:
            reasons.append("equity must be positive")
        cost_config = load_json("fees_config.json", {})
        buy_cost = estimate_order_charges(qty * entry, "BUY", order.get("exchange", "NSE"), order.get("mode", "intraday"), cost_config)
        stop_cost = estimate_order_charges(qty * stop, "SELL", order.get("exchange", "NSE"), order.get("mode", "intraday"), cost_config)
        slip = float(cost_config.get("slippage_bps", 5)) / 10000.0
        risk = max(0, qty * (entry - stop) + (entry + stop) * qty * slip + buy_cost["estimated_total_inr"] + stop_cost["estimated_total_inr"])
        equity = float(order.get("equity", config.get("paper_equity_inr", 100000)))
        if risk > float(config.get("max_loss_per_trade_inr", 500)):
            reasons.append("max loss per trade exceeded")
        if equity > 0 and qty * entry > equity * float(config.get("max_position_pct", 0.25)):
            reasons.append("maximum position exposure exceeded")
        if qty * entry > float(config.get("max_order_value_inr", 100000)):
            reasons.append("maximum order value exceeded")
        if equity > 0 and ledger:
            exposure = sum(float(item.get("average_price_inr", 0)) * int(item.get("quantity", 0))
                           for item in ledger.get("positions", {}).values())
            max_exposure = equity * float(config.get("max_portfolio_exposure_pct", 0.5))
            if exposure + qty * entry > max_exposure:
                reasons.append("maximum portfolio exposure exceeded")
            cash = ledger.get("cash_inr")
            if cash is None:
                cash = equity
            cash_floor = equity * float(config.get("cash_buffer_pct", 0.1))
            if float(cash) - qty * entry < cash_floor:
                reasons.append("cash buffer would be breached")
        target = order.get("target")
        if target is None or float(target) <= entry:
            reasons.append("a target above entry is required")
        else:
            minimum_rr = float(config.get("minimum_risk_reward", 1.5))
            if (float(target) - entry) / max(1e-12, entry - stop) < minimum_rr:
                reasons.append("minimum risk-reward not met")
    except (KeyError, TypeError, ValueError):
        risk = 0
        reasons.append("quantity, entry, stop, and target must be numeric")
    if ledger:
        trade_date = order.get("trade_date")
        day_orders = [item for item in ledger.get("orders", []) if item.get("trade_date") == trade_date]
        day_count = sum(1 for item in day_orders if item.get("side") == "BUY")
        if day_count >= int(config.get("max_trades_per_day", 3)):
            reasons.append("maximum trades per day reached")
        daily_pnl = sum(float(item.get("realized_pnl_inr", 0)) for item in day_orders)
        open_stop_risk = sum(max(0.0, float(item.get("average_price_inr", 0)) - float(item.get("stop_inr") or item.get("average_price_inr", 0)))
                             * int(item.get("quantity", 0)) for item in ledger.get("positions", {}).values())
        if daily_pnl - open_stop_risk - risk <= -float(config.get("max_daily_loss_inr", 1500)):
            reasons.append("daily loss limit including open-position stop risk would be breached")
    fee_complete = bool(locals().get("buy_cost", {}).get("estimate_complete") and locals().get("stop_cost", {}).get("estimate_complete"))
    return {"verdict": "PASS" if not reasons else "BLOCK", "reasons": reasons,
            "estimated_stop_risk_inr": round(risk, 2), "includes_slippage_and_estimated_costs": True,
            "fee_estimate_complete": fee_complete, "paper_only": True}
