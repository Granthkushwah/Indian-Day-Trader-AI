def evaluate_price(symbol, price, stop=None, target=None, exchange="NSE"):
    price = float(price)
    events = []
    if stop is not None and price <= float(stop):
        events.append({"type": "STOP", "level_inr": float(stop)})
    if target is not None and price >= float(target):
        events.append({"type": "TARGET", "level_inr": float(target)})
    return {"symbol": symbol.upper(), "exchange": exchange.upper(), "price_inr": price,
            "events": events, "delivery": "local_one_shot_check", "paper_only": True}
