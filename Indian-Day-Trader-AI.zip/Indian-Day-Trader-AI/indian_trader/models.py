from dataclasses import dataclass
from datetime import datetime


@dataclass
class Candle:
    timestamp: datetime
    exchange: str
    symbol: str
    interval: str
    open: float
    high: float
    low: float
    close: float
    volume: float
    token: str = ""
    source: str = "CSV"

    def validate(self):
        if self.exchange not in ("NSE", "BSE"):
            raise ValueError("exchange must be NSE or BSE")
        if not self.symbol.strip():
            raise ValueError("symbol is required")
        if min(self.open, self.high, self.low, self.close) <= 0:
            raise ValueError("OHLC values must be greater than zero")
        if self.high < max(self.open, self.close, self.low):
            raise ValueError("high must be >= open, close, and low")
        if self.low > min(self.open, self.close, self.high):
            raise ValueError("low must be <= open, close, and high")
        if self.volume < 0:
            raise ValueError("volume cannot be negative")
        return self

    def as_dict(self):
        return {
            "timestamp": self.timestamp.isoformat(), "exchange": self.exchange,
            "symbol": self.symbol, "interval": self.interval,
            "open": self.open, "high": self.high, "low": self.low,
            "close": self.close, "volume": self.volume,
            "token": self.token, "source": self.source,
        }
