from .scanner import scan_opening_range
from .indicators import sma


def evaluate(candles, symbol, mode="intraday", exchange=None, level=None):
    symbol = symbol.upper()
    mode = mode.lower()
    bars = [bar for bar in candles if bar.symbol == symbol and (exchange is None or bar.exchange == exchange.upper())]
    if mode == "intraday":
        bars = [bar for bar in bars if bar.interval in ("1m", "5m", "15m")]
    elif mode == "swing":
        bars = [bar for bar in bars if bar.interval == "1d"]
    else:
        raise ValueError("mode must be intraday or swing")
    bars.sort(key=lambda bar: bar.timestamp)
    if not bars:
        return {"status": "NO_DATA", "symbol": symbol, "mode": mode, "reason": "No matching bars"}
    last = bars[-1]
    if mode == "intraday":
        signals = scan_opening_range(bars)
        matched = [item for item in signals if item["symbol"] == symbol]
        if level is not None and last.close > float(level):
            return {"status": "TRIGGERED", "mode": mode, "symbol": symbol, "exchange": last.exchange,
                    "timestamp": last.timestamp.isoformat(), "price_inr": last.close, "level_inr": float(level),
                    "reason": "Last supplied completed bar closed above explicit level"}
        if matched and matched[-1]["timestamp"] == last.timestamp.isoformat():
            return {"status": "TRIGGERED", "mode": mode, "symbol": symbol, "exchange": last.exchange,
                    "timestamp": last.timestamp.isoformat(), "price_inr": last.close,
                    "level_inr": matched[-1]["range_high_inr"], "reason": "Completed bar closed above opening range"}
        return {"status": "WAITING", "mode": mode, "symbol": symbol, "exchange": last.exchange,
                "timestamp": last.timestamp.isoformat(), "price_inr": last.close,
                "reason": "No breakout on the last supplied completed bar"}
    if mode == "swing":
        if len(bars) < 21:
            return {"status": "INSUFFICIENT_DATA", "mode": mode, "symbol": symbol,
                    "reason": "At least 21 daily candles are needed for the 20-session breakout check"}
        prior_high = max(bar.high for bar in bars[-21:-1])
        avg = sma([bar.close for bar in bars[:-1]], 20)
        triggered = last.interval == "1d" and last.close > prior_high and last.close > avg
        return {"status": "TRIGGERED" if triggered else "WAITING", "mode": mode, "symbol": symbol,
                "exchange": last.exchange, "timestamp": last.timestamp.isoformat(), "price_inr": last.close,
                "level_inr": prior_high, "reason": "Daily close above prior 20-session high and average" if triggered else "No confirmed daily breakout"}
    raise ValueError("mode must be intraday or swing")
