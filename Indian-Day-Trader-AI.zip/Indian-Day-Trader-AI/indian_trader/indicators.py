def sma(values, period):
    if period <= 0 or len(values) < period:
        return None
    return sum(values[-period:]) / float(period)


def rsi(values, period=14):
    if len(values) <= period:
        return None
    changes = [values[index] - values[index - 1] for index in range(1, len(values))]
    window = changes[-period:]
    gains = sum(max(change, 0.0) for change in window) / period
    losses = sum(max(-change, 0.0) for change in window) / period
    if losses == 0:
        return 100.0 if gains else 50.0
    ratio = gains / losses
    return 100.0 - (100.0 / (1.0 + ratio))


def atr(candles, period=14):
    if len(candles) < period + 1:
        return None
    ranges = []
    for previous, current in zip(candles[-period-1:-1], candles[-period:]):
        ranges.append(max(current.high - current.low, abs(current.high - previous.close), abs(current.low - previous.close)))
    return sum(ranges) / float(period)
