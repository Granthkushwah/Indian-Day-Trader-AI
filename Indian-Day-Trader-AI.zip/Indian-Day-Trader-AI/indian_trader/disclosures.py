import csv
from pathlib import Path


def read_disclosures(path, symbol=None, change_threshold=1.0):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError("Disclosure CSV not found: {}".format(path))
    required = {"timestamp", "exchange", "symbol", "disclosure_type", "person_or_group", "shares",
                "holding_percent", "change_percent", "category", "title", "url", "source"}
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError("Missing disclosure columns: {}".format(", ".join(sorted(missing))))
        rows = []
        for row in reader:
            if symbol and row["symbol"].upper() != symbol.upper():
                continue
            try:
                change = float(row["change_percent"] or 0)
            except ValueError:
                change = 0
            row["large_reported_change"] = abs(change) >= float(change_threshold)
            row["interpretation"] = "disclosure_record_only_no_intent_inference"
            rows.append(row)
    return rows
