from .config import load_json


def estimate_order_charges(value, side, exchange="NSE", mode="intraday", config=None):
    config = config or load_json("fees_config.json", {})
    value, side = float(value), side.upper()
    exchange, mode = exchange.upper(), mode.lower()
    if value < 0 or side not in ("BUY", "SELL"):
        raise ValueError("value must be nonnegative and side must be BUY or SELL")
    rates = config.get("rates", {})
    broker = config.get("brokerage", {})
    exchange_rate = rates.get("transaction_rate_by_exchange", {}).get(exchange)
    transaction = (value * float(exchange_rate)) if exchange_rate is not None else None
    variable_brokerage = min(float(broker.get("cap_per_order_inr", 0)), value * float(broker.get("rate", 0)))
    brokerage = max(float(broker.get("minimum_inr", 0)), variable_brokerage) if value > 0 else 0.0
    sebi = value * float(rates.get("sebi_rate", 0))
    if mode == "intraday":
        stt = value * float(rates.get("stt_intraday_sell", 0)) if side == "SELL" else 0.0
        stamp = value * float(rates.get("stamp_intraday_buy", 0)) if side == "BUY" else 0.0
        dp = 0.0
    elif mode == "swing":
        stt = value * float(rates.get("stt_delivery_each_side", 0))
        stamp = value * float(rates.get("stamp_delivery_buy", 0)) if side == "BUY" else 0.0
        dp = float(rates.get("dp_sell_inr", 0)) if side == "SELL" else 0.0
    else:
        raise ValueError("mode must be intraday or swing")
    gst = (brokerage + (transaction or 0.0) + sebi + dp) * float(rates.get("gst_rate", 0))
    parts = {"brokerage_inr": round(brokerage, 4), "transaction_charges_inr": round(transaction, 4) if transaction is not None else None,
             "sebi_fee_inr": round(sebi, 4), "stt_inr": round(stt, 4), "stamp_duty_inr": round(stamp, 4),
             "gst_inr": round(gst, 4), "dp_charges_inr": round(dp, 4)}
    parts["estimated_total_inr"] = round(sum(value or 0.0 for value in parts.values()), 2)
    parts["estimate_complete"] = transaction is not None
    parts["fee_schedule_as_of"] = config.get("as_of")
    return parts


def estimate_round_trip(buy_value, sell_value, exchange="NSE", mode="intraday", config=None):
    buy = estimate_order_charges(buy_value, "BUY", exchange, mode, config)
    sell = estimate_order_charges(sell_value, "SELL", exchange, mode, config)
    return {"buy_side": buy, "sell_side": sell,
            "estimated_total_inr": round(buy["estimated_total_inr"] + sell["estimated_total_inr"], 2),
            "estimate_complete": buy["estimate_complete"] and sell["estimate_complete"],
            "fee_schedule_as_of": buy["fee_schedule_as_of"]}
