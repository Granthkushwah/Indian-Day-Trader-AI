import argparse
import json
import sys
from pathlib import Path

from . import __version__
from . import analyst, alerts, backtest, budget, calendar, disclosures, entry, exit_planner
from . import instruments, news, paper_broker, risk, scanner
from .config import load_json, project_root
from .data import load_bars
from .groww import GrowwDataClient, download_instruments as download_groww_instruments
from .groww import save_history as save_groww_history, search_instruments as search_groww_instruments
from .smartapi import SmartApiClient, save_history


def _emit(value, output=None):
    rendered = json.dumps(value, indent=2, ensure_ascii=False, default=str)
    if output:
        target = Path(output)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


def build_parser():
    parser = argparse.ArgumentParser(prog="indian-trader", description="NSE/BSE research and local paper trading only")
    parser.add_argument("--version", action="version", version="Indian Day Trader AI {}".format(__version__))
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("status", help="Show paper-only setup and session status")
    cal = commands.add_parser("calendar", help="Show an exchange session status")
    cal.add_argument("--exchange", choices=("NSE", "BSE"), default="NSE")
    cal.add_argument("--at", help="ISO timestamp; naive values are IST")
    cal.add_argument("--date", help="Date in YYYY-MM-DD")
    scan = commands.add_parser("scan", help="Scan user-supplied OHLCV bars")
    scan.add_argument("--file", required=True)
    scan.add_argument("--exchange", choices=("NSE", "BSE"))
    scan.add_argument("--min-volume-ratio", type=float, default=1.0,
                      help="Require breakout-bar volume at least this multiple of opening-range average")
    scan.add_argument("--out")
    news_cmd = commands.add_parser("news", help="Classify user-imported corporate announcement titles")
    news_cmd.add_argument("--file", required=True)
    news_cmd.add_argument("--symbol")
    entry_cmd = commands.add_parser("entry", help="Check completed bars for intraday or swing entry conditions")
    entry_cmd.add_argument("--file", required=True)
    entry_cmd.add_argument("--exchange", choices=("NSE", "BSE"), required=True)
    entry_cmd.add_argument("--symbol", required=True)
    entry_cmd.add_argument("--mode", choices=("intraday", "swing"), required=True)
    entry_cmd.add_argument("--level", type=float)
    exit_cmd = commands.add_parser("exit", help="Calculate stop, target and trailing reference")
    exit_cmd.add_argument("--entry", type=float, required=True)
    exit_cmd.add_argument("--stop", type=float, required=True)
    exit_cmd.add_argument("--risk-reward", type=float, default=2.0)
    exit_cmd.add_argument("--trailing-percent", type=float)
    budget_cmd = commands.add_parser("budget", help="Calculate INR position size under configured limits")
    budget_cmd.add_argument("--entry", type=float, required=True)
    budget_cmd.add_argument("--stop", type=float, required=True)
    budget_cmd.add_argument("--equity", type=float, default=None)
    budget_cmd.add_argument("--exchange", choices=("NSE", "BSE"), default="NSE")
    budget_cmd.add_argument("--mode", choices=("intraday", "swing"), default="intraday")
    risk_cmd = commands.add_parser("risk", help="Check a local JSON paper order")
    risk_cmd.add_argument("--order", required=True)
    risk_cmd.add_argument("--ledger", help="Paper ledger path (defaults to trader/paper_ledger.json)")
    paper = commands.add_parser("paper-order", help="Record a local simulated long or close fill")
    paper.add_argument("--side", choices=("BUY", "SELL"), required=True)
    paper.add_argument("--exchange", choices=("NSE", "BSE"), required=True)
    paper.add_argument("--symbol", required=True)
    paper.add_argument("--qty", type=int, required=True)
    paper.add_argument("--price", type=float, required=True, help="Reference price for the simulated fill")
    paper.add_argument("--mode", choices=("intraday", "swing"), required=True)
    paper.add_argument("--stop", type=float, help="Required for BUY")
    paper.add_argument("--target", type=float, help="Required for BUY")
    paper.add_argument("--equity", type=float)
    paper.add_argument("--ledger", help="Optional local ledger JSON path")
    paper_status = commands.add_parser("paper-status", help="Show simulated cash, positions and P&L")
    paper_status.add_argument("--ledger")
    bt = commands.add_parser("backtest", help="Run a bar-by-bar hypothetical strategy simulation")
    bt.add_argument("--file", required=True)
    bt.add_argument("--exchange", choices=("NSE", "BSE"), required=True)
    bt.add_argument("--symbol", required=True)
    bt.add_argument("--mode", choices=("intraday", "swing"), required=True)
    bt.add_argument("--equity", type=float, default=100000)
    bt.add_argument("--risk-reward", type=float, default=2.0)
    bt.add_argument("--out")
    alert = commands.add_parser("alerts", help="Evaluate a local one-shot price/stop/target alert")
    alert.add_argument("--symbol", required=True)
    alert.add_argument("--exchange", choices=("NSE", "BSE"), default="NSE")
    alert.add_argument("--price", type=float, required=True)
    alert.add_argument("--stop", type=float)
    alert.add_argument("--target", type=float)
    analyst_cmd = commands.add_parser("analyst", help="Summarize imported Indian company financial periods")
    analyst_cmd.add_argument("--file", required=True)
    analyst_cmd.add_argument("--symbol", required=True)
    disclosure_cmd = commands.add_parser("disclosures", help="Review imported insider/promoter disclosure records")
    disclosure_cmd.add_argument("--file", required=True)
    disclosure_cmd.add_argument("--symbol")
    disclosure_cmd.add_argument("--threshold", type=float, default=1.0)
    ins = commands.add_parser("instruments", help="Search a local Angel One instrument master")
    ins.add_argument("--file", required=True)
    ins.add_argument("--exchange", choices=("NSE", "BSE"))
    ins.add_argument("--query", default="")
    ins.add_argument("--limit", type=int, default=50)
    master = commands.add_parser("instruments-download", help="Download Angel One's public instrument reference file")
    master.add_argument("--out", default="data/angel_master.json")
    history = commands.add_parser("history", help="Fetch authorized SmartAPI historical candles")
    history.add_argument("--exchange", choices=("NSE", "BSE"), required=True)
    history.add_argument("--token", required=True)
    history.add_argument("--symbol", required=True)
    history.add_argument("--interval", choices=("1m", "5m", "15m", "1d"), required=True)
    history.add_argument("--from-date", required=True, help="SmartAPI format: YYYY-MM-DD HH:MM")
    history.add_argument("--to-date", required=True, help="SmartAPI format: YYYY-MM-DD HH:MM")
    history.add_argument("--out", required=True)
    quote = commands.add_parser("quote", help="Fetch one authorized SmartAPI current quote snapshot")
    quote.add_argument("--exchange", choices=("NSE", "BSE"), required=True)
    quote.add_argument("--token", required=True)
    groww_master = commands.add_parser("groww-instruments-download", help="Download Groww's public instrument CSV")
    groww_master.add_argument("--out", default="data/groww_instruments.csv")
    groww_ins = commands.add_parser("groww-instruments", help="Search a local Groww instrument CSV")
    groww_ins.add_argument("--file", required=True)
    groww_ins.add_argument("--exchange", choices=("NSE", "BSE"))
    groww_ins.add_argument("--segment", choices=("CASH", "FNO"), default="CASH")
    groww_ins.add_argument("--query", default="")
    groww_ins.add_argument("--limit", type=int, default=50)
    groww_history = commands.add_parser("groww-history", help="Fetch one symbol's authorized Groww historical candles")
    groww_history.add_argument("--exchange", choices=("NSE", "BSE"), required=True)
    groww_history.add_argument("--symbol", required=True, help="Groww symbol, e.g. RELIANCE or NSE-RELIANCE")
    groww_history.add_argument("--segment", choices=("CASH", "FNO"), default="CASH")
    groww_history.add_argument("--interval", choices=("1m", "2m", "3m", "5m", "10m", "15m", "30m", "1h", "4h", "1d", "1w", "1month"), required=True)
    groww_history.add_argument("--from-date", required=True, help="Groww format: YYYY-MM-DD HH:MM:SS")
    groww_history.add_argument("--to-date", required=True, help="Groww format: YYYY-MM-DD HH:MM:SS")
    groww_history.add_argument("--out", required=True)
    groww_quote = commands.add_parser("groww-quote", help="Fetch one authorized Groww live quote snapshot")
    groww_quote.add_argument("--exchange", choices=("NSE", "BSE"), required=True)
    groww_quote.add_argument("--symbol", required=True, help="Groww trading symbol, e.g. RELIANCE")
    groww_quote.add_argument("--segment", choices=("CASH", "FNO"), default="CASH")
    return parser


def run(args):
    if args.command == "status":
        return {"project": "Indian Day Trader AI", "version": __version__, "paper_trading": True,
                "live_trading": False, "options": False, "margin": False, "short_selling": False,
                "calendar": calendar.session_state(exchange="NSE"),
                "calendar_note": "Holiday list not verified until each exchange calendar is updated.",
                "market_data": "CSV offline by default; optional authorized Angel One SmartAPI or Groww candles/quotes; both adapters are read-only"}
    if args.command == "calendar":
        config = load_json("market_config.json", {})
        if args.date:
            check_date = args.date
            day = calendar.is_session_day(check_date, args.exchange, config)
            return {"exchange": args.exchange, "date": check_date, "session_day": day,
                    "verified": day is not None, "regular_open": config["regular_session"]["open"],
                    "regular_close": config["regular_session"]["close"]}
        from .data import parse_timestamp, IST
        at = parse_timestamp(args.at) if args.at else None
        return calendar.session_state(now=at or __import__("datetime").datetime.now(IST), exchange=args.exchange, config=config)
    if args.command == "scan":
        return _with_output(scanner.scan(load_bars(args.file, exchange=args.exchange), args.exchange, args.min_volume_ratio), args.out)
    if args.command == "news":
        return news.read_announcements(args.file, args.symbol)
    if args.command == "entry":
        return entry.evaluate(load_bars(args.file, exchange=args.exchange, symbol=args.symbol), args.symbol,
                              args.mode, args.exchange, args.level)
    if args.command == "exit":
        return exit_planner.make_plan(args.entry, args.stop, args.risk_reward, args.trailing_percent)
    if args.command == "budget":
        cfg = load_json("risk_config.json", {})
        return budget.size_position(args.entry, args.stop, args.equity or cfg.get("paper_equity_inr", 100000), cfg, args.exchange, args.mode)
    if args.command == "risk":
        with Path(args.order).open("r", encoding="utf-8") as handle:
            order = json.load(handle)
        from datetime import datetime
        from .data import IST
        order.setdefault("trade_date", datetime.now(IST).date().isoformat())
        return risk.check_order(order, ledger=paper_broker.load_ledger(args.ledger))
    if args.command == "paper-order":
        return paper_broker.execute_paper(args.side, args.exchange, args.symbol, args.qty, args.price, args.mode,
                                          args.ledger, equity=args.equity, stop=args.stop, target=args.target)
    if args.command == "paper-status":
        return paper_broker.summarize(path=args.ledger)
    if args.command == "backtest":
        result = backtest.run_backtest(load_bars(args.file, exchange=args.exchange, symbol=args.symbol), args.symbol,
                                       args.exchange, args.mode, args.equity, args.risk_reward)
        return _with_output(result, args.out)
    if args.command == "alerts":
        return alerts.evaluate_price(args.symbol, args.price, args.stop, args.target, args.exchange)
    if args.command == "analyst":
        return analyst.analyze_financials(args.file, args.symbol)
    if args.command == "disclosures":
        return disclosures.read_disclosures(args.file, args.symbol, args.threshold)
    if args.command == "instruments":
        return instruments.search_master(args.file, args.query, args.exchange, args.limit)
    if args.command == "instruments-download":
        return instruments.download_master(args.out)
    if args.command == "history":
        bars = save_history(SmartApiClient(), args.exchange, args.token, args.interval, args.from_date,
                            args.to_date, args.symbol, args.out)
        return {"saved": args.out, "bar_count": len(bars), "source": "AngelOneSmartAPI", "paper_only": True}
    if args.command == "quote":
        return {"exchange": args.exchange, "token": args.token, "quote": SmartApiClient().quote(args.exchange, args.token),
                "source": "AngelOneSmartAPI", "paper_only": True}
    if args.command == "groww-instruments-download":
        return download_groww_instruments(args.out)
    if args.command == "groww-instruments":
        return search_groww_instruments(args.file, args.query, args.exchange, args.segment, args.limit)
    if args.command == "groww-history":
        bars = save_groww_history(GrowwDataClient(), args.exchange, args.symbol, args.interval,
                                  args.from_date, args.to_date, args.out, segment=args.segment)
        return {"saved": args.out, "bar_count": len(bars), "source": "GrowwAPI", "paper_only": True}
    if args.command == "groww-quote":
        return {"exchange": args.exchange, "symbol": args.symbol,
                "quote": GrowwDataClient().quote(args.exchange, args.symbol, args.segment),
                "source": "GrowwAPI", "paper_only": True}
    raise ValueError("Unknown command")


def _with_output(value, output):
    if output:
        rendered = json.dumps(value, indent=2, ensure_ascii=False, default=str)
        target = Path(output)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(rendered + "\n", encoding="utf-8")
    return value


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        result = run(args)
        _emit(result)
        return 0
    except Exception as exc:
        print(json.dumps({"error": str(exc), "paper_only": True}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
