from collections import defaultdict

from .indicators import rsi, sma


def _bar_row(candle, setup, reason):
    return {"exchange": candle.exchange, "symbol": candle.symbol, "setup": setup,
            "timestamp": candle.timestamp.isoformat(), "price_inr": round(candle.close, 4),
            "volume": candle.volume, "source": candle.source, "reason": reason}


def scan_daily(candles):
    groups = defaultdict(list)
    for candle in candles:
        if candle.interval == "1d":
            groups[(candle.exchange, candle.symbol)].append(candle)
    results = []
    for bars in groups.values():
        bars.sort(key=lambda bar: bar.timestamp)
        close = [bar.close for bar in bars]
        last = bars[-1]
        if len(bars) >= 21:
            previous_high = max(bar.high for bar in bars[-21:-1])
            if last.close > previous_high:
                results.append(_bar_row(last, "20d_high_breakout", "Close above prior 20 sessions' high"))
            avg = sma(close[:-1], 20)
            previous_avg = sma(close[:-2], 20)
            if avg and previous_avg and close[-2] <= previous_avg and last.close > avg:
                results.append(_bar_row(last, "sma20_reclaim", "Close crossed above prior 20-session average"))
        current_rsi = rsi(close, 14)
        prior_rsi = rsi(close[:-1], 14) if len(close) > 15 else None
        if current_rsi is not None and current_rsi < 30:
            results.append(_bar_row(last, "oversold_rsi", "RSI(14) below 30; context only"))
        elif current_rsi is not None and prior_rsi is not None and prior_rsi <= 30 < current_rsi and last.close > bars[-2].close:
            results.append(_bar_row(last, "oversold_bounce", "RSI crossed above 30 with a higher close"))
        if len(bars) >= 8:
            prior = bars[-8:-3]
            impulse = prior[-1].close / max(1e-12, prior[0].close) - 1.0
            flag = bars[-3:-1]
            flag_range = (max(item.high for item in flag) - min(item.low for item in flag)) / max(1e-12, flag[-1].close)
            if impulse >= 0.06 and flag_range <= 0.04 and last.close > max(item.high for item in flag):
                results.append(_bar_row(last, "bull_flag", "Strong recent advance, tight pause, then close above pause"))
    return results


def scan_opening_range(candles, opening_minutes=15, min_volume_ratio=1.0):
    groups = defaultdict(list)
    for candle in candles:
        if candle.interval in ("1m", "5m", "15m"):
            groups[(candle.exchange, candle.symbol, candle.interval, candle.timestamp.date())].append(candle)
    results = []
    for bars in groups.values():
        bars.sort(key=lambda bar: bar.timestamp)
        first = bars[0]
        open_time = first.timestamp.replace(hour=9, minute=15, second=0, microsecond=0)
        end_time = open_time + __import__("datetime").timedelta(minutes=opening_minutes)
        opening = [bar for bar in bars if open_time <= bar.timestamp < end_time]
        later = [bar for bar in bars if bar.timestamp >= end_time]
        if not opening or not later:
            continue
        range_high = max(bar.high for bar in opening)
        opening_average_volume = sum(bar.volume for bar in opening) / float(len(opening))
        for bar in later:
            volume_ratio = bar.volume / opening_average_volume if opening_average_volume > 0 else None
            if bar.close > range_high and (volume_ratio is None or volume_ratio >= min_volume_ratio):
                results.append({"exchange": bar.exchange, "symbol": bar.symbol, "setup": "opening_range_breakout",
                                "timestamp": bar.timestamp.isoformat(), "price_inr": round(bar.close, 4),
                                "volume": bar.volume, "source": bar.source,
                                "volume_ratio_to_opening_average": round(volume_ratio, 3) if volume_ratio is not None else None,
                                "reason": "Completed bar closed above first {}-minute range with volume ratio {:.2f}".format(opening_minutes, volume_ratio or 0),
                                "range_high_inr": round(range_high, 4)})
                break
    return results


def scan(candles, exchange=None, min_volume_ratio=1.0):
    if exchange:
        candles = [bar for bar in candles if bar.exchange == exchange.upper()]
    return scan_daily(candles) + scan_opening_range(candles, min_volume_ratio=min_volume_ratio)
