import json
from datetime import datetime
from pathlib import Path

from .calendar import IST
from .config import project_root, load_json, save_json
from .costs import estimate_order_charges


def ledger_path(path=None):
    return Path(path) if path else project_root() / "trader" / "paper_ledger.json"


def load_ledger(path=None):
    path = ledger_path(path)
    if not path.exists():
        return {"paper_only": True, "orders": [], "positions": {}, "cash_inr": None, "realized_pnl_inr": 0.0}
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if data.get("paper_only") is not True:
        raise ValueError("Ledger paper_only flag is missing/false; refusing to use ledger")
    return data


def execute_paper(side, exchange, symbol, quantity, reference_price, mode="intraday", path=None,
                  config=None, slippage_bps=None, equity=None, stop=None, target=None):
    side, exchange, symbol, mode = side.upper(), exchange.upper(), symbol.upper(), mode.lower()
    quantity, reference_price = int(quantity), float(reference_price)
    if side not in ("BUY", "SELL"):
        raise ValueError("paper broker supports BUY and SELL-to-close only")
    if exchange not in ("NSE", "BSE") or mode not in ("intraday", "swing"):
        raise ValueError("exchange must be NSE/BSE and mode must be intraday/swing")
    if quantity <= 0 or reference_price <= 0:
        raise ValueError("quantity and reference_price must be positive")
    risk_config = config or load_json("risk_config.json", {})
    fees_config = load_json("fees_config.json", {})
    slippage_bps = float(slippage_bps if slippage_bps is not None else fees_config.get("slippage_bps", 5))
    fill = reference_price * (1 + slippage_bps / 10000.0) if side == "BUY" else reference_price * (1 - slippage_bps / 10000.0)
    fill = round(fill, 4)
    current = load_ledger(path)
    key = "{}:{}".format(exchange, symbol)
    position = current.setdefault("positions", {}).get(key, {"exchange": exchange, "symbol": symbol,
                                                               "quantity": 0, "average_price_inr": 0.0,
                                                               "mode": mode, "buy_costs_inr": 0.0,
                                                               "stop_inr": None, "target_inr": None})
    if side == "SELL" and quantity > int(position["quantity"]):
        raise ValueError("Cannot sell more than the local simulated long position")
    if side == "BUY" and not config:
        # Safety defaults are applied below as well; explicit risk data remains user-editable.
        pass
    if side == "BUY":
        active_config = risk_config
        now_for_risk = datetime.now(IST).isoformat()
        order = {"side": side, "exchange": exchange, "symbol": symbol, "mode": mode, "quantity": quantity,
                 "entry": fill, "stop": stop, "target": target,
                 "equity": float(equity if equity is not None else active_config.get("paper_equity_inr", 100000)),
                 "trade_date": now_for_risk[:10]}
        from .risk import check_order
        verdict = check_order(order, active_config, current)
        if verdict["verdict"] != "PASS":
            raise ValueError("Paper order blocked: {}".format("; ".join(verdict["reasons"])))
    costs = estimate_order_charges(fill * quantity, side, exchange, mode, fees_config)
    if side == "BUY":
        new_qty = int(position["quantity"]) + quantity
        old_cost = float(position["quantity"]) * float(position["average_price_inr"])
        position["average_price_inr"] = round((old_cost + fill * quantity) / new_qty, 4)
        position["quantity"] = new_qty
        position["buy_costs_inr"] = round(float(position.get("buy_costs_inr", 0)) + costs["estimated_total_inr"], 2)
        position["mode"] = mode
        if stop is not None:
            existing_stop = position.get("stop_inr")
            position["stop_inr"] = float(stop) if existing_stop is None else min(float(existing_stop), float(stop))
        if target is not None:
            position["target_inr"] = float(target)
    else:
        old_qty = int(position["quantity"])
        allocated_entry_cost = float(position.get("buy_costs_inr", 0)) * quantity / old_qty
        realized = (fill - float(position["average_price_inr"])) * quantity - costs["estimated_total_inr"] - allocated_entry_cost
        current["realized_pnl_inr"] = round(float(current.get("realized_pnl_inr", 0)) + realized, 2)
        position["quantity"] = old_qty - quantity
        position["buy_costs_inr"] = round(float(position.get("buy_costs_inr", 0)) - allocated_entry_cost, 2)
        if position["quantity"] == 0:
            position["average_price_inr"] = 0.0
            position["buy_costs_inr"] = 0.0
    notional = fill * quantity
    if current.get("cash_inr") is None:
        current["cash_inr"] = float(equity if equity is not None else risk_config.get("paper_equity_inr", 100000))
    current["cash_inr"] = round(float(current["cash_inr"]) - notional - costs["estimated_total_inr"] if side == "BUY"
                                else float(current["cash_inr"]) + notional - costs["estimated_total_inr"], 2)
    if side == "BUY" and current["cash_inr"] < float(equity if equity is not None else risk_config.get("paper_equity_inr", 100000)) * float(risk_config.get("cash_buffer_pct", 0.1)):
        raise ValueError("Paper order rejected: configured cash buffer would be breached")
    if position["quantity"] > 0:
        current["positions"][key] = position
    else:
        current["positions"].pop(key, None)
    now = datetime.now(IST).isoformat()
    order_record = {"id": "PAPER-{:05d}".format(len(current.get("orders", [])) + 1), "timestamp": now,
                    "trade_date": now[:10], "side": side, "exchange": exchange, "symbol": symbol,
                    "mode": mode, "quantity": quantity, "reference_price_inr": reference_price,
                    "fill_price_inr": fill, "slippage_bps": slippage_bps,
                    "estimated_costs": costs, "realized_pnl_inr": round(realized, 2) if side == "SELL" else 0.0,
                    "status": "SIMULATED_FILLED"}
    current.setdefault("orders", []).append(order_record)
    save_json(ledger_path(path), current)
    return {"order": order_record, "ledger_summary": summarize(current)}


def summarize(ledger=None, path=None, marks=None):
    ledger = ledger or load_ledger(path)
    marks = marks or {}
    positions = []
    unrealized = 0.0
    for key, item in ledger.get("positions", {}).items():
        mark = float(marks.get(key, item["average_price_inr"]))
        pnl = (mark - float(item["average_price_inr"])) * int(item["quantity"]) - float(item.get("buy_costs_inr", 0))
        unrealized += pnl
        positions.append({"key": key, "quantity": item["quantity"], "average_price_inr": item["average_price_inr"],
                          "mark_inr": mark, "unrealized_pnl_inr": round(pnl, 2), "mode": item.get("mode")})
    return {"paper_only": True, "cash_inr": ledger.get("cash_inr"), "realized_pnl_inr": ledger.get("realized_pnl_inr", 0),
            "unrealized_pnl_inr": round(unrealized, 2), "positions": positions, "order_count": len(ledger.get("orders", []))}
