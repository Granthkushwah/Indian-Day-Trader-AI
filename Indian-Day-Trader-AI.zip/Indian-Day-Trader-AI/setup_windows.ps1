$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "Python 3.8+ was not found. Install Python and enable PATH, then run setup again."
}
python -c "import sys; assert sys.version_info >= (3,8), 'Python 3.8 or newer is required'; print('Python', sys.version.split()[0])"
if (-not (Test-Path ".venv")) { python -m venv .venv }
New-Item -ItemType Directory -Force data,trader,logs,reports | Out-Null
foreach ($p in @("data\.gitkeep", "trader\.gitkeep", "logs\.gitkeep", "reports\.gitkeep")) {
    if (-not (Test-Path $p)) { New-Item -ItemType File -Path $p | Out-Null }
}
Write-Host "Setup complete. Activate with .\.venv\Scripts\Activate.ps1"
Write-Host "Then run: python -m indian_trader.cli status"
