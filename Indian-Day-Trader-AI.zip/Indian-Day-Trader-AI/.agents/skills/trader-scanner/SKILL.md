---
name: trader-scanner
description: Scan authorized NSE/BSE OHLCV for daily breakouts, bull flags, moving-average reclaims, RSI setups, and intraday opening-range breakouts.
---

# trader-scanner

Use when the user asks to scan Indian stocks, NSE/BSE, ORB, bull flags, momentum, oversold bounces, or daily setups.

1. Confirm the exchange and authorized input CSV are known. Never invent symbols or prices.
2. Run `python -m indian_trader.cli scan --file <bars.csv> --exchange <NSE|BSE> [--min-volume-ratio 1.0]` from this project root. The default ORB scan requires breakout-bar volume at least equal to average opening-range bar volume.
3. Explain that output covers only supplied rows and is a research condition, not a trade recommendation. Name timestamps and data source.
4. If data is missing, explain that the project can download historical candles one symbol at a time from the optional Angel One or Groww read-only adapters. For Groww, the user must first dot-source `.\scripts\groww_data_login.ps1` locally; never ask them to paste credentials into chat. The Groww instrument master is metadata, not prices, and full-market batch downloads are not implemented. Do not scrape or bypass feed terms.
