---
name: trader-alerts
description: Evaluate a one-shot NSE/BSE price, stop, target, or regular-session condition in IST.
---

# trader-alerts

Use for a price/stop/target check or session status. Run `python -m indian_trader.cli alerts --symbol <SYMBOL> --exchange NSE|BSE --price <INR> [--stop <INR>] [--target <INR>]`. For session status use `python -m indian_trader.cli calendar --exchange NSE|BSE`. This is a local one-shot check, not a background alert service; unknown holiday calendars remain unknown.
