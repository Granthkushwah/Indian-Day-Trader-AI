---
name: trader-timemachine
description: Replay an intraday or swing setup on supplied NSE/BSE bars with slippage, estimated charges, drawdown and risk statistics.
---

# trader-timemachine

Use for a historical simulation or win/loss question. Run `python -m indian_trader.cli backtest --file <bars.csv> --exchange <NSE|BSE> --symbol <SYMBOL> --mode <intraday|swing>`. Summarize trades, net INR P&L, win rate, average R and drawdown. Stop distance, slippage, fees, and configured position caps constrain simulated quantity. Explain that no point-in-time universe is included, so survivorship bias is not controlled. Results are hypothetical.
