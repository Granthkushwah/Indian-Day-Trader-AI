---
name: trader-pelosi
description: Review imported Indian insider and promoter filings, shareholding changes and exchange announcements from official sources.
---

# trader-pelosi

Use for promoter/insider disclosure checks. Run `python -m indian_trader.cli disclosures --file <disclosures.csv> [--symbol SYMBOL] [--threshold 1]`. Prefer official NSE/BSE/SEBI records and retain links and timestamps. Report disclosure facts only; do not infer intent, guilt, or trade direction.
