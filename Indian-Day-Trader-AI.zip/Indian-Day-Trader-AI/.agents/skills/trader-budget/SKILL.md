---
name: trader-budget
description: Size a long NSE/BSE paper position in INR based on entry, stop, equity and risk limits.
---

# trader-budget

Use when asked for quantity, budget, or max loss. Run `python -m indian_trader.cli budget --entry <INR> --stop <INR> --equity <INR> --exchange <NSE|BSE> --mode <intraday|swing>`. Report shares and which cap limits size. Never remove the required stop or exceed configured limits.
