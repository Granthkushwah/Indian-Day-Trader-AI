---
name: trader-broker
description: Record local simulated Angel One-style paper fills and positions; Angel One is used only as an optional market-data source.
---

# trader-broker

Use for a paper order, simulated position, order history, or simulated P&L. Run `python -m indian_trader.cli paper-order --side BUY|SELL --exchange NSE|BSE --symbol <SYMBOL> --qty N --price <INR> --mode intraday|swing`; BUY also requires `--stop` and `--target`. Use `paper-status` to review the local ledger. Explain that price is a user-supplied reference and simulated fills are not realistic execution. Never send an Angel One order or ask for secrets.
