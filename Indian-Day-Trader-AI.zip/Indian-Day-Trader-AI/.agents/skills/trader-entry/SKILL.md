---
name: trader-entry
description: Check completed NSE/BSE intraday opening-range or swing breakout conditions using user-provided bars.
---

# trader-entry

Use when timing an intraday or swing paper setup. Ask for exchange, symbol, mode, and an authorized CSV if absent.

Run `python -m indian_trader.cli entry --file <bars.csv> --exchange <NSE|BSE> --symbol <SYMBOL> --mode <intraday|swing>`. An optional `--level <INR>` checks a supplied intraday level. The CLI uses completed bars only; report `WAITING`, `TRIGGERED`, or `INSUFFICIENT_DATA` as returned. This is not an order signal.
