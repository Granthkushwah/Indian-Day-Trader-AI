---
name: trader-exit
description: Calculate INR stop, target, risk per share, and optional trailing-stop reference for a long paper plan.
---

# trader-exit

Use to plan a protective exit before sizing. Run `python -m indian_trader.cli exit --entry <INR> --stop <INR> [--risk-reward 2] [--trailing-percent N]`. The stop must be below entry. State that a calculated stop cannot guarantee a fill through gaps or illiquidity.
