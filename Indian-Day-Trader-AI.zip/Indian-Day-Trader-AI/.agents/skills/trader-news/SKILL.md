---
name: trader-news
description: Review user-imported NSE/BSE corporate announcements and group them by event keywords without claiming price impact.
---

# trader-news

Use for Indian company news, exchange filings, earnings announcements, market-moving events, or a news review.

Run `python -m indian_trader.cli news --file <announcements.csv> [--symbol SYMBOL]`. Prefer official NSE/BSE/company URLs and show the source timestamp. Keyword tags are not sentiment or price predictions. Do not treat an unavailable attachment as confirmed.
