---
name: trader-analyst
description: Summarize Indian company financial periods and calculate simple growth and margin ratios from sourced CSV data.
---

# trader-analyst

Use for quarterly results, margins, earnings analysis, or balance-sheet metrics. Run `python -m indian_trader.cli analyst --file <financials.csv> --symbol <SYMBOL>`. Preserve source units and period labels. This arithmetic summary is not a valuation or investment recommendation.
