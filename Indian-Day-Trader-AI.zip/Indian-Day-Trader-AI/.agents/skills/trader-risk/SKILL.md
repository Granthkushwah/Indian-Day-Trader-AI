---
name: trader-risk
description: Apply INR position, stop, reward-risk and paper-only checks to a local order JSON before simulated entry.
---

# trader-risk

Use before a simulated entry or when asked whether a proposed paper order fits configured controls. Run `python -m indian_trader.cli risk --order <order.json>`. The order needs side BUY, exchange, symbol, mode, quantity, entry, stop, target, and optional equity. The command reads the local paper ledger for current trade count, cash, exposure and stop risk; use `--ledger <path>` for another paper ledger. Return PASS/BLOCK and list reasons. Sell-to-close is only handled by the local paper broker. Live execution is unavailable.
