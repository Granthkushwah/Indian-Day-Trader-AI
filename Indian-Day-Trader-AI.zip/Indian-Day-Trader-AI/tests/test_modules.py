import csv
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from indian_trader.alerts import evaluate_price
from indian_trader.analyst import analyze_financials
from indian_trader.disclosures import read_disclosures
from indian_trader.instruments import download_master, normalize_exchange, search_master
from indian_trader.news import classify, read_announcements


class ModuleTests(unittest.TestCase):
    def test_news_tags_and_record_import(self):
        self.assertIn("earnings", classify("Quarterly Results declared"))
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "news.csv"
            path.write_text("timestamp,exchange,symbol,category,title,url,source\n2026-01-01,NSE,T,results,Quarterly results,https://example.test,NSE\n", encoding="utf-8")
            row = read_announcements(path, "T")[0]
            self.assertEqual(row["impact"], "not_assessed")

    def test_analyst_metrics_and_provenance(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "financials.csv"
            path.write_text("period_end,symbol,revenue,operating_income,net_income,eps,total_assets,total_debt,equity,source,url\n2025-03-31,T,100,20,10,1,200,40,100,issuer,https://example.test\n2025-06-30,T,120,24,12,1.2,220,40,110,issuer,https://example.test\n", encoding="utf-8")
            result = analyze_financials(path, "T")
            self.assertAlmostEqual(result["periods"][1]["sequential_revenue_growth"], 0.2)
            self.assertAlmostEqual(result["periods"][0]["net_margin"], 0.1)

    def test_analyst_year_over_year_and_valuation_when_supplied(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "financials.csv"
            rows = [
                "2025-03-31,T,100,20,10,2,200,40,100,issuer,https://example.test,200,1000",
                "2025-06-30,T,110,20,10,2,200,40,100,issuer,https://example.test,200,1000",
                "2025-09-30,T,120,20,10,2,200,40,100,issuer,https://example.test,200,1000",
                "2025-12-31,T,130,20,10,2,200,40,100,issuer,https://example.test,200,1000",
                "2026-03-31,T,150,30,15,3,220,40,110,issuer,https://example.test,210,1100",
            ]
            path.write_text("period_end,symbol,revenue,operating_income,net_income,eps,total_assets,total_debt,equity,source,url,market_price_inr,market_cap_inr\n" + "\n".join(rows) + "\n", encoding="utf-8")
            result = analyze_financials(path, "T")
            self.assertAlmostEqual(result["periods"][-1]["year_over_year_revenue_growth"], 0.5)
            self.assertAlmostEqual(result["periods"][-1]["valuation"]["price_to_earnings"], 70)
            self.assertAlmostEqual(result["periods"][-1]["valuation"]["price_to_book"], 10)

    def test_disclosure_records_no_intent_claim(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "disc.csv"
            path.write_text("timestamp,exchange,symbol,disclosure_type,person_or_group,shares,holding_percent,change_percent,category,title,url,source\n2026-01-01,NSE,T,PIT,group,100,5,1.2,insider,change,https://example.test,NSE\n", encoding="utf-8")
            row = read_disclosures(path, "T")[0]
            self.assertTrue(row["large_reported_change"])
            self.assertEqual(row["interpretation"], "disclosure_record_only_no_intent_inference")

    def test_instruments_local_master_search(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "master.json"
            path.write_text(json.dumps([{"symbol": "TEST-EQ", "token": "123", "exch_seg": "nse_cm", "name": "Test"},
                                        {"symbol": "TEST-B", "token": "456", "exch_seg": "bse_cm", "name": "Test"}]), encoding="utf-8")
            hits = search_master(path, "TEST", "NSE")
            self.assertEqual(hits[0]["token"], "123")
            self.assertEqual(hits[0]["exchange"], "NSE")
            self.assertEqual(normalize_exchange("bse_cm"), "BSE")
            self.assertEqual(len(search_master(path, "TEST", "BSE")), 1)

    def test_instrument_master_download_writes_valid_json_without_network(self):
        class FakeResponse:
            headers = {}
            def __enter__(self):
                return self
            def __exit__(self, exc_type, exc_value, traceback):
                return False
            def read(self):
                return b'[{"symbol":"TEST-EQ","token":"123","exch_seg":"nse_cm"}]'
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "data" / "master.json"
            with patch("indian_trader.instruments.urlopen", return_value=FakeResponse()):
                result = download_master(path)
            self.assertEqual(result["record_count"], 1)
            self.assertEqual(search_master(path, "TEST", "NSE")[0]["token"], "123")

    def test_one_shot_alert(self):
        result = evaluate_price("TEST", 90, stop=95, target=110, exchange="BSE")
        self.assertEqual(result["events"][0]["type"], "STOP")


if __name__ == "__main__":
    unittest.main()
