import unittest
from pathlib import Path

from indian_trader.cli import build_parser
from indian_trader import analyst, alerts, backtest, budget, disclosures, entry, exit_planner, news, paper_broker, risk, scanner


ROOT = Path(__file__).resolve().parents[1]
SKILL_MAP = {
    "trader-scanner": scanner.scan,
    "trader-news": news.read_announcements,
    "trader-entry": entry.evaluate,
    "trader-exit": exit_planner.make_plan,
    "trader-timemachine": backtest.run_backtest,
    "trader-budget": budget.size_position,
    "trader-risk": risk.check_order,
    "trader-broker": paper_broker.execute_paper,
    "trader-alerts": alerts.evaluate_price,
    "trader-analyst": analyst.analyze_financials,
    "trader-pelosi": disclosures.read_disclosures,
}


class SkillTests(unittest.TestCase):
    def test_every_skill_has_codex_metadata_and_shared_callable(self):
        parser = build_parser()
        self.assertIsNotNone(parser)
        self.assertEqual(len(SKILL_MAP), 11)
        for name, function in SKILL_MAP.items():
            with self.subTest(skill=name):
                skill_file = ROOT / ".agents" / "skills" / name / "SKILL.md"
                self.assertTrue(skill_file.is_file())
                content = skill_file.read_text(encoding="utf-8")
                self.assertTrue(content.startswith("---\nname: {}\n".format(name)))
                self.assertIn("python -m indian_trader.cli", content)
                self.assertTrue(callable(function))


if __name__ == "__main__":
    unittest.main()
