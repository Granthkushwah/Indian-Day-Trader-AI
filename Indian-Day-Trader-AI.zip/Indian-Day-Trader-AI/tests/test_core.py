import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

from indian_trader.backtest import run_backtest
from indian_trader.budget import size_position
from indian_trader.calendar import is_session_day, session_state
from indian_trader.costs import estimate_order_charges
from indian_trader.data import IST, load_bars
from indian_trader.entry import evaluate
from indian_trader.exit_planner import make_plan
from indian_trader.models import Candle
from indian_trader.paper_broker import execute_paper, load_ledger, summarize
from indian_trader.risk import check_order
from indian_trader.scanner import scan
from indian_trader.smartapi import SmartApiClient, SmartApiError


def candle(day, minute, price, high=None, low=None, volume=1000, interval="5m", symbol="TEST"):
    hour = 9 + minute // 60
    minute = minute % 60
    return Candle(datetime(2026, 1, day, hour, minute, tzinfo=IST), "NSE", symbol, interval,
                  price, high if high is not None else price + 0.4,
                  low if low is not None else price - 0.4, price, volume, source="TEST_ONLY_NOT_MARKET_DATA")


class CoreTests(unittest.TestCase):
    def test_candle_validation_and_csv_reader(self):
        with self.assertRaises(ValueError):
            Candle(datetime.now(IST), "NYSE", "X", "5m", 10, 9, 8, 10, 1).validate()
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "bars.csv"
            path.write_text("timestamp,exchange,symbol,interval,open,high,low,close,volume\n2026-01-05T09:15:00,NSE,T,5m,10,11,9,10.5,100\n", encoding="utf-8")
            bars = load_bars(path)
            self.assertEqual(len(bars), 1)
            self.assertEqual(bars[0].timestamp.tzinfo, IST)

    def test_scanner_and_entry_orb_completed_bars(self):
        bars = [candle(5, 15, 100), candle(5, 20, 101), candle(5, 25, 100.5), candle(5, 30, 102, high=102.5)]
        results = scan(bars, "NSE")
        self.assertEqual(results[0]["setup"], "opening_range_breakout")
        result = evaluate(bars, "TEST", "intraday", "NSE")
        self.assertEqual(result["status"], "TRIGGERED")
        quiet_breakout = [candle(5, 15, 100, volume=2000), candle(5, 20, 100, volume=2000),
                          candle(5, 25, 100, volume=2000), candle(5, 30, 102, high=103, volume=500)]
        self.assertEqual(scan(quiet_breakout, "NSE"), [])

    def test_swing_entry_and_daily_scanner(self):
        days = [Candle(datetime(2026, 1, index + 1, 15, 0, tzinfo=IST), "NSE", "TEST", "1d",
                       100, 101, 99, 100, 1000, source="TEST_ONLY_NOT_MARKET_DATA") for index in range(20)]
        days.append(Candle(datetime(2026, 2, 1, 15, 0, tzinfo=IST), "NSE", "TEST", "1d",
                           102, 103, 101, 102, 2000, source="TEST_ONLY_NOT_MARKET_DATA"))
        result = evaluate(days, "TEST", "swing", "NSE")
        self.assertEqual(result["status"], "TRIGGERED")
        self.assertIn("20d_high_breakout", [item["setup"] for item in scan(days, "NSE")])

    def test_exit_budget_risk(self):
        plan = make_plan(100, 95, 2)
        self.assertEqual(plan["target_inr"], 110)
        sized = size_position(100, 95, 100000)
        self.assertLessEqual(sized["max_loss_at_stop_inr"], 500)
        good = {"side": "BUY", "exchange": "NSE", "symbol": "TEST", "mode": "intraday", "quantity": 5,
                "entry": 100, "stop": 95, "target": 110, "equity": 100000}
        self.assertEqual(check_order(good)["verdict"], "PASS")
        good["stop"] = 100
        self.assertEqual(check_order(good)["verdict"], "BLOCK")

    def test_calendar_uses_verified_nse_2026_and_fails_closed_elsewhere(self):
        self.assertFalse(is_session_day("2026-11-14", "NSE"))  # Saturday
        self.assertFalse(is_session_day("2026-11-10", "NSE"))  # verified exchange holiday
        self.assertTrue(is_session_day("2026-11-16", "NSE"))
        self.assertIsNone(is_session_day("2026-11-16", "BSE"))
        status = session_state(datetime(2026, 11, 16, 10, 0, tzinfo=IST), "NSE")
        self.assertTrue(status["open"])

    def test_calendar_does_not_apply_a_verified_holiday_list_to_another_year(self):
        config = {"holidays": {"NSE": {"verified": True, "year": 2026, "dates": []}}}
        self.assertIsNone(is_session_day("2027-01-04", "NSE", config))

    def test_costs_mark_bse_incomplete(self):
        nse = estimate_order_charges(10000, "BUY", "NSE", "intraday")
        bse = estimate_order_charges(10000, "BUY", "BSE", "intraday")
        self.assertTrue(nse["estimate_complete"])
        self.assertFalse(bse["estimate_complete"])

    def test_paper_ledger_buy_sell_and_pnl(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "ledger.json"
            bought = execute_paper("BUY", "NSE", "TEST", 5, 100, "intraday", path=path, stop=95, target=110)
            self.assertEqual(bought["order"]["status"], "SIMULATED_FILLED")
            sold = execute_paper("SELL", "NSE", "TEST", 5, 110, "intraday", path=path)
            self.assertGreater(sold["order"]["realized_pnl_inr"], 0)
            self.assertEqual(summarize(load_ledger(path))["positions"], [])
            self.assertTrue(load_ledger(path)["paper_only"])

    def test_backtest_uses_next_bar_and_reports_limitations(self):
        bars = [candle(5, minute, price, high=high, low=low) for minute, price, high, low in [
            (15, 100, 101, 99), (20, 101, 102, 100), (25, 100, 101, 99),
            (30, 103, 104, 102), (35, 104, 105, 103), (40, 105, 106, 104)]]
        result = run_backtest(bars, "TEST", "NSE", "intraday")
        self.assertEqual(result["status"], "OK")
        self.assertEqual(result["trade_count"], 1)
        self.assertTrue(result["trades"][0]["entry_time_ordered_after_signal"])
        self.assertFalse(result["survivorship_bias_control"])

    def test_swing_backtest_and_mixed_intraday_rejection(self):
        daily = [Candle(datetime(2026, 1, index + 1, 15, 0, tzinfo=IST), "NSE", "TEST", "1d",
                        100, 101, 99, 100, 1000, source="TEST_ONLY_NOT_MARKET_DATA") for index in range(20)]
        daily.extend([
            Candle(datetime(2026, 2, 1, 15, 0, tzinfo=IST), "NSE", "TEST", "1d", 102, 104, 101, 103, 2000, source="TEST_ONLY_NOT_MARKET_DATA"),
            Candle(datetime(2026, 2, 2, 15, 0, tzinfo=IST), "NSE", "TEST", "1d", 103, 104, 102, 103, 2000, source="TEST_ONLY_NOT_MARKET_DATA"),
        ])
        result = run_backtest(daily, "TEST", "NSE", "swing")
        self.assertEqual(result["trade_count"], 1)
        self.assertEqual(result["mode"], "swing")
        mixed = [candle(5, 15, 100, interval="1m"), candle(5, 20, 100, interval="5m")]
        with self.assertRaises(ValueError):
            run_backtest(mixed, "TEST", "NSE", "intraday")

    def test_smartapi_requires_credentials_without_exposing_them(self):
        try:
            SmartApiClient(api_key=None, access_token=None)._headers()
        except SmartApiError as exc:
            self.assertIn("ANGELONE_API_KEY", str(exc))
        else:
            self.fail("Missing credentials should fail closed")

    def test_smartapi_data_headers_use_local_session_network_values(self):
        values = {"ANGELONE_LOCAL_IP": "192.168.1.5", "ANGELONE_PUBLIC_IP": "203.0.113.5",
                  "ANGELONE_MAC_ADDRESS": "aa:bb:cc:dd:ee:ff"}
        with patch.dict("os.environ", values):
            headers = SmartApiClient(api_key="local-test-key", access_token="local-test-token")._headers()
        self.assertEqual(headers["X-ClientLocalIP"], "192.168.1.5")
        self.assertEqual(headers["X-ClientPublicIP"], "203.0.113.5")
        self.assertEqual(headers["X-MACAddress"], "aa:bb:cc:dd:ee:ff")

    def test_risk_blocks_cash_buffer_and_daily_loss(self):
        order = {"side": "BUY", "exchange": "NSE", "symbol": "TEST", "mode": "intraday", "quantity": 5,
                 "entry": 100, "stop": 95, "target": 110, "equity": 10000, "trade_date": "2026-01-05"}
        ledger = {"cash_inr": 1000, "positions": {}, "orders": []}
        self.assertIn("cash buffer would be breached", check_order(order, ledger=ledger)["reasons"])
        ledger["cash_inr"] = 10000
        ledger["orders"] = [{"side": "SELL", "trade_date": "2026-01-05", "realized_pnl_inr": -1500}]
        self.assertTrue(any("daily loss limit" in reason for reason in check_order(order, ledger=ledger)["reasons"]))

    def test_end_to_end_cli_scan_plan_risk_paper_ledger(self):
        from indian_trader.cli import build_parser, run
        from contextlib import redirect_stdout
        import io
        with tempfile.TemporaryDirectory() as temp:
            bars_path = Path(temp) / "bars.csv"
            bars_path.write_text("timestamp,exchange,symbol,interval,open,high,low,close,volume\n"
                                 "2026-01-05T09:15:00+05:30,NSE,TEST,5m,100,101,99,100,1000\n"
                                 "2026-01-05T09:20:00+05:30,NSE,TEST,5m,100,101,99,100,1000\n"
                                 "2026-01-05T09:25:00+05:30,NSE,TEST,5m,100,101,99,100,1000\n"
                                 "2026-01-05T09:30:00+05:30,NSE,TEST,5m,102,103,101,102,1500\n", encoding="utf-8")
            with redirect_stdout(io.StringIO()):
                scan_result = run(build_parser().parse_args(["scan", "--file", str(bars_path), "--exchange", "NSE"]))
                entry_result = run(build_parser().parse_args(["entry", "--file", str(bars_path), "--exchange", "NSE", "--symbol", "TEST", "--mode", "intraday"]))
                plan = run(build_parser().parse_args(["exit", "--entry", "102", "--stop", "100"]))
                sizing = run(build_parser().parse_args(["budget", "--entry", "102", "--stop", "100", "--equity", "100000"]))
                order_file = Path(temp) / "order.json"
                order_file.write_text(__import__("json").dumps({"side": "BUY", "exchange": "NSE", "symbol": "TEST", "mode": "intraday",
                                      "quantity": 2, "entry": 102, "stop": 100, "target": 106, "equity": 100000}), encoding="utf-8")
                verdict = run(build_parser().parse_args(["risk", "--order", str(order_file)]))
                ledger_path = Path(temp) / "ledger.json"
                result = run(build_parser().parse_args(["paper-order", "--side", "BUY", "--exchange", "NSE", "--symbol", "TEST",
                                  "--qty", "2", "--price", "102", "--mode", "intraday", "--stop", "100", "--target", "106",
                                  "--ledger", str(ledger_path)]))
            self.assertTrue(scan_result)
            self.assertEqual(entry_result["status"], "TRIGGERED")
            self.assertEqual(plan["target_inr"], 106)
            self.assertGreater(sizing["quantity"], 0)
            self.assertEqual(verdict["verdict"], "PASS")
            self.assertTrue(result["ledger_summary"]["paper_only"])


if __name__ == "__main__":
    unittest.main()
