# Indian Day Trader AI (NSE + BSE)

Windows 11 ke liye paper-trading research toolkit. Is project mein 11 Codex Agent Skills, shared Python commands, CSV data import, Angel One SmartAPI aur Groww ke read-only market-data adapters, INR risk checks, local simulated broker, and intraday/swing backtest shamil hain.

> **Safety:** Paper mode hamesha on hai. Code mein live order placement implemented nahi hai. Angel One ya Groww credentials chat mein share na karein. Broker API data access ke liye account permissions, current API terms, subscription/entitlements, and exchange data rights verify karein.

## Quick start (Windows)

1. Python 3.8+ install karein. PowerShell mein project folder kholen.
2. `.\setup_windows.ps1` run karein. Ye local `.venv` banata hai aur dependencies install karta hai (abhi standard library only).
3. `.\.venv\Scripts\Activate.ps1` se environment activate karein.
4. `python -m indian_trader.cli status` chala kar setup status dekhein.
5. CSV file apne licensed/authorized data se `data\` mein rakhein. Format `docs\DATA_FORMATS.md` mein hai. Koi sample market prices bundle nahi kiye gaye.

## Commands

```powershell
python -m indian_trader.cli --help
python -m indian_trader.cli instruments-download --out data/angel_master.json
python -m indian_trader.cli instruments --file data\angel_master.json --exchange NSE --query RELIANCE
python -m indian_trader.cli scan --file data\bars.csv --exchange NSE
python -m indian_trader.cli news --file data\announcements.csv
python -m indian_trader.cli entry --file data\bars.csv --exchange NSE --symbol RELIANCE --mode intraday
python -m indian_trader.cli exit --entry 2500 --stop 2475 --risk-reward 2
python -m indian_trader.cli budget --entry 2500 --stop 2475 --equity 100000
python -m indian_trader.cli risk --order trader\pending_order.json
python -m indian_trader.cli paper-order --side BUY --exchange NSE --symbol RELIANCE --qty 5 --price 2500 --mode swing
python -m indian_trader.cli backtest --file data\bars.csv --exchange NSE --symbol RELIANCE --mode swing
python -m indian_trader.cli alerts --symbol RELIANCE --price 2520 --stop 2475 --target 2550
python -m indian_trader.cli analyst --file data\financials.csv --symbol RELIANCE
python -m indian_trader.cli disclosures --file data\disclosures.csv --symbol RELIANCE
```

For Angel One or Groww setup, see `docs\WINDOWS_SETUP.md` for the local hidden-prompt login, instrument-master lookup, candle download, and scan sequence. Keep the selected login helper dot-sourced in the same PowerShell window where you run its data commands.

Commands CSV ke column requirements `docs\DATA_FORMATS.md` mein hain. `--help` har command ke options dikhata hai. CLI outputs research only hain, buy/sell recommendation nahi.

## Codex Agent Skills

Repo mein `.agents\skills\trader-*\SKILL.md` files hain. Codex ko project root dikhayein/open karein; skills repo context mein discover hongi. Personal install ke liye `Copy-Item -Recurse .agents\skills\* "$HOME\.agents\skills\"` chalayein. Har skill ka invoke-when aur command uske `SKILL.md` mein hai. Skills sirf local CLI commands chalane ke liye guidance deti hain.

## Data sources and status

- **CSV:** Implemented; columns/date-time validation included. Bring data you are permitted to use.
- **Angel One SmartAPI:** Historical candles and current quote snapshots have a data-only REST adapter with conservative request pacing. `scripts\angelone_data_login.ps1` prompts locally and keeps the short-lived access token in the current PowerShell session only. Login/data connectivity was not tested against a live account. No order endpoint is implemented.
- **Groww API:** Historical candles, current quote snapshots, and public instrument CSV search have a read-only REST adapter. `scripts\groww_data_login.ps1` prompts locally, creates a short-lived session from Groww API Key + Secret (daily approval required) or accepts a Groww Access Token, and keeps the access token in the current PowerShell session only. Login/data connectivity was not tested against a live account. The adapter contains no order endpoint. Groww data access may require an active API subscription and the correct data entitlement.
- **Corporate announcements/fundamentals/disclosures:** Analyzer and CSV import implemented. Exchange feeds are not scraped or redistributed. Add official source links and retrieval timestamps to imported records.
- **Calendar:** Regular NSE/BSE equity cash timings are set to 09:15–15:30 IST. Official NSE 2026 dates are included; BSE and future-year dates remain unknown until verified in `config/market_config.json`. Special sessions need explicit configuration.
- **Fees:** Editable indicative defaults in `config/fees_config.json`; check broker/exchange schedule for trade date before relying on an estimate.
- **Backtest:** Supports intraday and swing bars, slippage and configured charges. It cannot remove survivorship bias unless you supply point-in-time universe membership and corporate-action adjusted data. Results are hypothetical, not forecasts.

## Install/update

See `docs\WINDOWS_SETUP.md`, `docs\USAGE.md`, `docs\SOURCE_INSPECTION.md`, `docs\GAP_ANALYSIS.md`, `docs\ARCHITECTURE.md` and `docs\SOURCES.md`. Configuration examples are under `config\`. Runtime state is under `trader\`; reports under `reports\`; logs under `logs\`.

## Verify

From the project root: `python -m unittest discover -s tests -v`. This suite uses local deterministic unit inputs only; it does not call a broker or download market data.
